package com.ibms.purchases.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ibms.common.util.common.BeanUtils;
import com.ibms.common.util.common.UserContextUtil;
import com.ibms.common.util.file.FileUtil;
import com.ibms.common.util.string.StringUtil;
import com.ibms.rest.file.model.SunFile;
import com.ibms.rest.service.impl.FileServiceImpl;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MyFileUtil {



    public static Map<String,String[]> toArrayMap(Map<String,Object> params){
        Map<String,String[]> resMap = new HashMap<>();
        String[] keyArr = new String[params.size()];
        String[] valArr = new String[params.size()];
        int index = 0;
        for(String key:params.keySet()){
            keyArr[index] = key;
            valArr[index] = CommonTools.Obj2String(params.get(key));
            ++index;
        }
        resMap.put("keyArr",keyArr);
        resMap.put("valArr",valArr);
        return resMap;
    }


}