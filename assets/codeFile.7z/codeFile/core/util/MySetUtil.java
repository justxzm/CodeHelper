package com.ibms.purchases.util;

import java.util.HashSet;
import java.util.Set;

public class MySetUtil {

    public static String toString(Set<String> strSet, String splitMark){
        final String[] res = {""};
        splitMark = CommonTools.Obj2String(splitMark);
        if(isNotEmpty(strSet)){
            String finalSplitMark = splitMark;
            strSet.stream().forEach(item->{
                res[0] += finalSplitMark + item;
            });
            res[0] = res[0].substring(1);
        }
        return res[0];
    }

    public static String[] toArray(Set<String> strSet){
        String[] res = null;
        if(isNotEmpty(strSet)){
            res = new String[strSet.size()];
            int index = 0;
            for(String str:strSet){
                res[index++] = str;
            }
        }
        return res;
    }

    public static <T> boolean isNotEmpty(Set<T> anySet){
        boolean isNotEmpty = false;
        if(anySet!=null && anySet.size()>0){
            isNotEmpty = true;
        }
        return isNotEmpty;
    }

    public static <T> Set<T> getInitSet(T val){
        Set<T> res = new HashSet<>();
        if(val!=null){
            res.add(val);
        }
        return res;
    }
}