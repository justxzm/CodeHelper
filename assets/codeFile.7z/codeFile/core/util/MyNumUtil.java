package com.ibms.purchases.util;

import java.math.BigDecimal;

public class MyNumUtil {

    public static Long add(Long... numArr){
        Long res = 0L;
        if(numArr.length>0){
            for(Long num:numArr){
                res += CommonTools.obj2Long(num);
            }
        }
        return res;
    }

    public static Long sub(Long... numArr){
        Long res = 0L;
        if(numArr.length>0){
            res = CommonTools.obj2Long(numArr[0])*2;
            for(Long num:numArr){
                res -= CommonTools.obj2Long(num);
            }
        }
        return res;
    }

    public static double add(Object v1, Object v2, int scale) {
        BigDecimal b1 = new BigDecimal(toDoubleStr(v1));
        BigDecimal b2 = new BigDecimal(toDoubleStr(v2));
        return b1.add(b2).setScale(scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public static double sub(Object v1, Object v2, int scale) {
        BigDecimal b1 = new BigDecimal(toDoubleStr(v1));
        BigDecimal b2 = new BigDecimal(toDoubleStr(v2));
        return b1.subtract(b2).setScale(scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public static double mul(Object v1, Object v2, int scale) {
        BigDecimal b1 = new BigDecimal(toDoubleStr(v1));
        BigDecimal b2 = new BigDecimal(toDoubleStr(v2));
        return b1.multiply(b2).setScale(scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public static double div(Object v1, Object v2, int scale) {
        BigDecimal b1 = new BigDecimal(toDoubleStr(v1));
        BigDecimal b2 = new BigDecimal(toDoubleStr(v2));
        return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public static String fixed(Object val, int scale) {
        BigDecimal bd = new BigDecimal(toDoubleStr(val));
        bd = bd.setScale(scale, BigDecimal.ROUND_HALF_UP);
        return bd.toPlainString();
    }

    public static String toDoubleStr(Object val){
        return CommonTools.Obj2String(CommonTools.obj2Double(val));
    }
}