package com.ibms.purchases.util;

import com.ibms.common.util.string.StringUtil;

import java.text.DecimalFormat;
import java.util.*;
import java.util.function.Function;

public class MyStringUtil {

    /**
     *  @desc : 将字符串数字转成千分位显示
     *  @createDate : 2023/12/7 17:14
     */
    public static String comdify(Object val, int scale) {
        return comdify(MyNumUtil.fixed(val,scale));
    }
    public static String comdify(Object val) {
        String value = CommonTools.Obj2String(val);
        DecimalFormat df = null;
        if (value.indexOf(".") > 0) {
            int i = value.length() - value.indexOf(".") - 1;
            switch (i) {
                case 0:
                    df = new DecimalFormat("###,##0");
                    break;
                case 1:
                    df = new DecimalFormat("###,##0.0");
                    break;
                case 2:
                    df = new DecimalFormat("###,##0.00");
                    break;
                case 3:
                    df = new DecimalFormat("###,##0.000");
                    break;
                case 4:
                    df = new DecimalFormat("###,##0.0000");
                    break;
                default:
                    df = new DecimalFormat("###,##0.00000");
                    break;
            }

        } else {
            df = new DecimalFormat("###,##0");
        }
        double number = 0.0;
        try {
            number = CommonTools.obj2Double(value);
        } catch (Exception e) {
            number = 0.0;
        }
        return CommonTools.Obj2String(df.format(number));
    }


    /**
     *  @desc : 去除部分
     *  @createDate : 2024/3/26 13:48
     */
    public static String removePartion(String source, String partion, String split){
        source = CommonTools.Obj2String(source);
        partion = CommonTools.Obj2String(partion);
        split = CommonTools.Obj2String(split);
        source = source.replace(partion + split, "")
                .replace(split + partion, "")
                .replace(partion, "");
        return source;
    }

    /**
     *  @desc : 去除前缀
     *  @createDate : 2023/3/22 10:31
     */
    public static String removePrefix(String source, String prefix){
        if(StringUtil.isNotEmpty(source) && StringUtil.isNotEmpty(prefix)){
            source = (source.startsWith(prefix)? source.substring(prefix.length()):source);
        }
        return source;
    }

    /**
     *  @desc : 去除后缀
     *  @createDate : 2023/3/22 10:31
     */
    public static String removeSuffix(String source, String suffix){
        if(StringUtil.isNotEmpty(source) && StringUtil.isNotEmpty(suffix)){
            source = (source.endsWith(suffix)? source.substring(0,source.length()-suffix.length()):source);
        }
        return source;
    }

    /**
     *  @desc : 拼接多个值
     *  @createDate : 2023/4/7 17:56
     */
    public static String joinMultiVal(String split, String... vals){
        String res = "";
        for(String val:vals){
            if(StringUtil.isNotEmpty(val)){
                res += val + split;
            }
        }
        res = removeSuffix(res,split);
        return res;
    }

    /**
     *  @desc : 分割去重
     *  @createDate : 2023/2/10 15:08
     */
    public static String removeRepeat(Object strObj, String split){
        String str = CommonTools.Obj2String(strObj);
        return MySetUtil.toString(toSet(str,split),split);
    }

    /**
     *  @desc : 分割转Set
     *  @createDate : 2023/2/10 15:08
     */
    public static Set<String> toSet(String str, String splitMark){
        Set<String> res = new HashSet<>();
        if(StringUtil.isNotEmpty(str)){
            Arrays.stream(str.split(splitMark)).forEach(item->{
                if(StringUtil.isNotEmpty(item)){
                    res.add(item);
                }
            });
        }
        return res;
    }

    /**
     *  @desc	    : sql过滤，多个值“或”判断，判断逻辑自实现
     *  @createDate : 2023/2/10 15:09
     */
    public static String getFilterSql(Function myFunc, String[] fieldValueArr){
        String resFilterSql = "";
        if(fieldValueArr!=null && fieldValueArr.length>0) {
            String splitStr = " OR ";
            Set<String> valSet = new HashSet<>();
            for (String fieldValue : fieldValueArr) {
                fieldValue = CommonTools.Obj2String(fieldValue);
                if (!valSet.contains(fieldValue)) {
                    resFilterSql += myFunc.apply(fieldValue) + splitStr;
                    valSet.add(fieldValue);
                }
            }
            resFilterSql = " AND (" + resFilterSql.substring(0, resFilterSql.length() - splitStr.length()) + ") ";
        }else{
            resFilterSql = " AND 1=2 ";
        }
        return resFilterSql;
    }
    public static String getFilterSql(Function myFunc, Set<String> fieldValueSet){
        String resFilterSql = "";
        if(fieldValueSet!=null && fieldValueSet.size()>0) {
            String splitStr = " OR ";
            for (String fieldValue : fieldValueSet) {
                fieldValue = CommonTools.Obj2String(fieldValue);
                resFilterSql += myFunc.apply(fieldValue) + splitStr;
            }
            resFilterSql = " AND (" + resFilterSql.substring(0, resFilterSql.length() - splitStr.length()) + ") ";
        }else{
            resFilterSql = " AND 1=2 ";
        }
        return resFilterSql;
    }
    public static String getFilterSql(Function myFunc, List<Map<String, Object>> dataList, String fieldName){
        String resFilterSql = "";
        if(CommonTools.isNotEmptyList(dataList)){
            String splitStr = " OR ";
            Set<String> valSet = new HashSet<>();
            for(Map<String, Object> dataMap:dataList){
                String fieldVal = CommonTools.Obj2String(dataMap.get(fieldName));
                if(!valSet.contains(fieldVal)){
                    resFilterSql += myFunc.apply(fieldVal) + splitStr;
                    valSet.add(fieldVal);
                }
            }
            resFilterSql = " AND (" + resFilterSql.substring(0,resFilterSql.length()-splitStr.length()) + ") ";
        }else{
            resFilterSql = " AND 1=2 ";
        }
        return resFilterSql;
    }
    public static <T> String getFilterSql(Function myFunc, List<T> dataList){
        String resFilterSql = "";
        if(CommonTools.isNotEmptyList(dataList)){
            String splitStr = " OR ";
            Set<String> valSet = new HashSet<>();
            for(T dataMap:dataList){
                String fieldVal = CommonTools.Obj2String(myFunc.apply(dataMap));
                if(!valSet.contains(fieldVal)){
                    resFilterSql += fieldVal + splitStr;
                    valSet.add(fieldVal);
                }
            }
            resFilterSql = " AND (" + resFilterSql.substring(0,resFilterSql.length()-splitStr.length()) + ") ";
        }else{
            resFilterSql = " AND 1=2 ";
        }
        return resFilterSql;
    }
}