package com.ibms.purchases.util.controller;

import com.alibaba.fastjson.JSONObject;
import com.ibms.common.swagger.annotation.ApiGroup;
import com.ibms.common.util.common.HttpUtil;
import com.ibms.common.util.common.UserContextUtil;
import com.ibms.common.util.string.StringUtil;
import com.ibms.common.web.response.Response;
import com.ibms.project.common.swagger.constants.ProjectApiGroupConsts;
import com.ibms.purchases.util.MyConst;
import com.ibms.purchases.util.lscPrint.service.LscPrintService;
import com.ibms.purchases.util.manager.MyUtilManager;
import com.ibms.resource.log.annotation.QueryLog;
import com.ibms.resource.web.annotation.ResourceClass;
import com.ibms.resource.web.annotation.ResourceMethod;
import com.ibms.rest.project.print.model.PrintInfo;
import com.ibms.rest.project.print.model.PrintResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;


@Api(tags = "工具接口")
@ApiGroup(group = {ProjectApiGroupConsts.GROUP_OFFICIAL})
@RestController
@RequestMapping("/purchases/myUtil/")
@ResourceClass(modulePath = "official.myUtil", moduleName = "工具接口")
public class MyUtilController {

    @Resource
    private MyUtilManager manager;

    @PostMapping(value = "updateFlowStatus")
    @ApiOperation(value = "更新流程数据状态", httpMethod = "POST", notes = "更新流程数据状态")
    @ResourceMethod(methodName = "更新流程数据状态")
    public Response<Void> updateFlowStatus(@RequestBody JSONObject params,
                                           @RequestParam("tableName") String tableName,
                                           @RequestParam("fieldName") String fieldName,
                                           @RequestParam("status") String status,
                                           @RequestParam("subTableName") String subTableName,
                                           @RequestParam("subFieldName") String subFieldName,
                                           @RequestParam("subStatus") String subStatus) {
        return this.manager.updateFlowStatus(params.getString("businessKey"), tableName, fieldName, status, subTableName, subFieldName, subStatus);
    }

    @PostMapping(value = "updateStatus")
    @ApiOperation(value = "更新数据状态", httpMethod = "POST", notes = "更新数据状态")
    @ResourceMethod(methodName = "更新数据状态")
    public Response<Void> updateStatus(@RequestBody JSONObject params) {
        String ids = params.getString("ids");
        String tableName = params.getString("tableName");
        String fieldName = params.getString("fieldName");
        String status = params.getString("status");
        String refIds = params.getString("refIds");
        String subTableName = params.getString("subTableName");
        String subFieldName = params.getString("subFieldName");
        String subStatus = params.getString("subStatus");
        return this.manager.updateStatus(ids, tableName, fieldName, status,
                                        refIds, subTableName, subFieldName, subStatus);
    }

    @PostMapping(value = "isUserChargeOrgByCode")
    @ApiOperation(value = "判断用户是否为某组织负责人", httpMethod = "POST", notes = "判断用户是否为某组织负责人")
    @ResourceMethod(methodName = "判断用户是否为某组织负责人")
    public Response<Boolean> isUserChargeOrgByCode(@RequestBody JSONObject params) {
        String userCode = params.getString("userCode");
        String orgCode = params.getString("orgCode");
        String orgIsDelete = params.getString("orgIsDelete");
        userCode = StringUtil.isEmpty(userCode)? UserContextUtil.getCurrentUserCode():userCode;
        orgCode = MyConst.purchaseOrgCode.equals(orgCode)? MyConst.purchaseOrgCode:orgCode;//前端采购部门编码统一替换
        orgCode = StringUtil.isEmpty(orgCode)? UserContextUtil.getCurrentUserOrgCode():orgCode;
        orgIsDelete = StringUtil.isEmpty(orgIsDelete)? "0":orgIsDelete;
        return this.manager.isUserChargeOrgByCode(userCode,orgCode,orgIsDelete);
    }

    @PostMapping(value = "getDicInfoMap")
    @ApiOperation(value = "获取数据字典信息", httpMethod = "POST", notes = "获取数据字典信息")
    @ResourceMethod(methodName = "获取数据字典信息")
    public Response<Map<String,Object>> getDicInfoMap(@RequestParam("dicAlias") String dicAlias,
                                                      @RequestParam(value = "clientNum",required = false) String clientNum) {
        if(StringUtil.isEmpty(clientNum)){
            clientNum = HttpUtil.getClientNum();
        }
        return new Response<Map<String,Object>>().success(this.manager.getDicAllInfoMap(dicAlias,clientNum));
    }

    @PostMapping(value = "sendToLscPrint")
    @ApiOperation(value = "推立思辰打印", httpMethod = "POST", notes = "推立思辰打印")
    @ResourceMethod(methodName = "推立思辰打印")
    @QueryLog
    public Response<Void> sendToLscPrint(@RequestParam("funcName") String funcName,
                                                @RequestParam("fileName") String fileName,
                                                @RequestParam("filePath") String filePath) {
        return this.manager.sendToLscPrint(funcName,fileName,filePath);
    }

    @PostMapping(value = "dealWithHadoopFile")
    @ApiOperation(value = "数据迁移hadoop文件处理", httpMethod = "POST", notes = "数据迁移hadoop文件处理")
    @ResourceMethod(methodName = "数据迁移hadoop文件处理")
    public Response<Void> dealWithHadoopFile(@RequestParam("tableName") String tableName,
                                             @RequestParam("fieldName") String fieldName,
                                             @RequestParam(value = "dataSource",required = false) String dataSource) {
        return this.manager.dealWithHadoopFile(tableName,fieldName,dataSource);
    }
}