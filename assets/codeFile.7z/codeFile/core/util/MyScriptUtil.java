package com.ibms.purchases.util;

import com.alibaba.fastjson.JSONObject;

public class MyScriptUtil {

    //得到业务主表ID
    public static String getBusinessKey(JSONObject params){
        return params.getString("businessKey");
    }

    //得到业务表名
    public static String getTableAlias(JSONObject params){
        return params.getJSONObject("boData").getString("boDefAlias");
    }
    public static String getTableName(JSONObject params){
        return "w_"+getTableAlias(params);
    }

    //得到业务数据
    public static JSONObject getBoData(JSONObject params){
        return params.getJSONObject("boData").getJSONObject(getTableAlias(params));
    }

    //得到业务主表字段值
    public static String getFieldVal(JSONObject params, String fieldName){
        JSONObject boData = getBoData(params);
        return boData.getString(fieldName);
    }

    //得到操作种类
    public static String getActionType(JSONObject params){
        return params.getJSONObject("actionDef").getString("actionType");
    }
}