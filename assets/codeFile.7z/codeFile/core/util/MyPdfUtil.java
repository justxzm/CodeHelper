package com.ibms.purchases.util;


import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.*;
import org.springframework.core.io.ClassPathResource;

import java.io.*;
import java.util.List;
import java.util.Map;

public class MyPdfUtil {


    public static byte[] getMergedBytes(String templateFilePath, Map<String, Object> txtFillMap,
                                           Map<String, byte[]> imgFillMap){
        ClassPathResource resource = new ClassPathResource(templateFilePath);//加载模板
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        try {
            fillData(resource.getInputStream(),byteOut,txtFillMap,imgFillMap);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return byteOut.toByteArray();
    }

    public static void mergeData(InputStream is, String outFile, Map<String, Object> txtFillMap, Map<String, byte[]> imgFillMap) {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(outFile);
            fillData(is,fos,txtFillMap,imgFillMap);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void fillData(InputStream is, OutputStream os, Map<String, Object> txtFillMap, Map<String, byte[]> imgFillMap) {
        try {
            PdfReader reader = new PdfReader(is);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PdfStamper stamp = new PdfStamper(reader, baos);
            AcroFields form = stamp.getAcroFields();
            // 设置字体，否则可能会不显示中文
            BaseFont bf = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
            form.addSubstitutionFont(bf);
            if (txtFillMap != null) {
                fillTxt(form, txtFillMap);
            }
            if (imgFillMap != null) {
                fillImage(stamp, form, imgFillMap);
            }
            stamp.setFormFlattening(true);
            stamp.close();
            Document doc = new Document();
            PdfCopy pdfCopy = new PdfCopy(doc, os);
            doc.open();
            PdfImportedPage impPage = pdfCopy.getImportedPage(new PdfReader(baos.toByteArray()), 1);
            pdfCopy.addPage(impPage);
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void fillTxt(AcroFields form, Map<String, Object> txtFillMap) throws IOException, DocumentException {
        for (String key : txtFillMap.keySet()) {
            String value = CommonTools.Obj2String(txtFillMap.get(key));
            form.setField(key, value);
        }
    }

    private static void fillImage(PdfStamper stamp, AcroFields form, Map<String, byte[]> imgFillMap) throws DocumentException, IOException {
        for (String fieldName:imgFillMap.keySet()) {
            byte[] imgBytes = imgFillMap.get(fieldName);
            if(imgBytes!=null){
                List<AcroFields.FieldPosition> fieldPositions = form.getFieldPositions(fieldName);
                if(fieldPositions!=null){
                    for (AcroFields.FieldPosition fieldPosition : fieldPositions) {
                        int pageno = fieldPosition.page;
                        Rectangle signrect = fieldPosition.position;
                        float x = signrect.getLeft();
                        float y = signrect.getBottom();
                        Image image = Image.getInstance(imgBytes);
                        PdfContentByte under = stamp.getOverContent(pageno);
                        image.scaleToFit(signrect.getWidth(), signrect.getHeight());
                        image.setAbsolutePosition(x, y);
                        under.addImage(image);
                    }
                }
            }
        }
    }
}
