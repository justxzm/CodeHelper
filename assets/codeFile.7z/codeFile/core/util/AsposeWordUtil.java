package com.ibms.purchases.util;

import com.aspose.words.*;
import com.aspose.words.net.System.Data.DataRelation;
import com.aspose.words.net.System.Data.DataRow;
import com.aspose.words.net.System.Data.DataSet;
import com.aspose.words.net.System.Data.DataTable;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.ibms.common.util.date.DateUtil;
import com.ibms.common.util.string.StringUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.ResourcePropertySource;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * AsposeWordUtil : word文档打印内容值替换操作类
 *
 * @author NATSU
 */
@Getter
@Setter
@NoArgsConstructor
public class AsposeWordUtil {

    private Document doc;
    private DocumentBuilder builder;
    private Integer imgTopPadding = 2;
    private Integer imgBottomPadding = 2;
    private Integer imgCellSpacing = 5;
    private int imageWidth = 100;
    private int imageHeight = 50;

    /**
     * 获取util实例
     */
    public AsposeWordUtil(String templateName) throws Exception {
        //1.加载授权文件
        this.loadLicense();
        //2.得到模板对象
        ClassPathResource classPathResource = new ClassPathResource("template/" + templateName);
        InputStream inputStream = classPathResource.getInputStream();
        doc = new Document(inputStream);
        builder = new DocumentBuilder(doc);
    }

    public AsposeWordUtil(InputStream stream) throws Exception {
        //1.加载授权文件
        this.loadLicense();
        doc = new Document(stream);
        builder = new DocumentBuilder(doc);
    }

    /**
     * 注册
     */
    public void loadLicense() {
        License license = new License();
        InputStream is = null;
        try {
            is = this.getClass().getResourceAsStream("/aspose.word.license.xml");
            if (is == null) {
                throw new RuntimeException("Cannot find licenses file.");
            }
            license.setLicense(is);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 书签替换
     */
    public void replaceBookMarks(Map<String, Object> dataMap) {

        Map<String, Object> kv = new HashMap<>();
        BookmarkCollection collections = builder.getDocument().getRange().getBookmarks();
        collections.forEach(bookmark -> {
            if (null != bookmark) {
                //获取书签名称
                String markName = bookmark.getName();
                //获取书签类型
                if (!markName.contains("_")) {
                    return;
                }
                String markType = markName.substring(0, markName.indexOf("_"));
                if ("IGNORE".equals(markType.toUpperCase(Locale.ROOT))) {
                    return;
                }
                //获取书签真实名称：markType_markKey，如果标签重复显示同一个字段：markType_markKey》序号,统一带F_
                String markKey = "F_" + markName.substring(markName.indexOf("_") + 1);
                //不带F_
                String markKeyCopy = markName.substring(markName.indexOf("_") + 1);

                System.out.println("标签: " + markName + "、" + markKeyCopy);

                if (dataMap.containsKey(markKey) || dataMap.containsKey(markKeyCopy) || "checkbox".equals(markType)) {

                    //获取书签对应的替换值
                    Object markValue = dataMap.get(markKey) == null ? "" : dataMap.get(markKey);
                    if ("".equals(markValue)) {
                        markValue = dataMap.get(markKeyCopy) == null ? "" : dataMap.get(markKeyCopy);
                    }
                    if ("checkbox".equals(markType)) {
                        String[] marKeyArr = markKey.split("_");
                        markValue = dataMap.get("F_" + marKeyArr[1]) == null ? "" : dataMap.get("F_" + marKeyArr[1]);
                        if ("HASVLAVE".equals(marKeyArr[2])) {
                            if (!"".equals(markValue.toString())) {
                                markValue = "true";
                            } else {
                                markValue = "false";
                            }
                        } else {
                            if("ZGLX".equals(marKeyArr[1]) || "JL".equals(marKeyArr[1])){//转固类型、结论
                                if(markValue.toString().equals(marKeyArr[2])){
                                    markValue = "true";
                                }else{
                                    markValue = "false";
                                }
                            }else{
                                if (markValue.toString().contains(marKeyArr[2])) {
                                    markValue = "true";
                                } else {
                                    markValue = "false";
                                }
                            }
                        }
                    }

                    System.out.println(markValue);

                    kv.put(markName, markValue);
                    switch (markType.toUpperCase(Locale.ROOT)) {
                        case "TEXT":
                            //普通文本直接替换
                            replaceBookMarkText(bookmark, markValue.toString());
                            break;
                        case "IMAGE":
                            //图片书签,插入图片
                            doReplaceImageMarkValue(bookmark, markValue);
                            break;
                        case "CODE":
                            //条形码替换
                            replaceBookMarkCode(bookmark, markValue.toString());
                            break;
                        case "FLOW":
                            //流程意见替换
                            replaceBookFlowValue(bookmark, markValue.toString());
                            break;
                        case "CHECKBOX":
                            //复选框
                            doReplaceCheckBoxMarkValue(bookmark, markValue.toString());
                            break;
                        case "CHECKBOX1":
                            //复选框单个字段
                            doReplaceMultiCheckBoxMarkValue(bookmark, markValue.toString());
                            break;
                        default:
                            break;
                    }
                }
            }
        });
        System.err.println(kv);
    }

    //流程相关替换
    private void replaceBookFlowValue(Bookmark mark, String value) {
        try {
            String markName = mark.getName();
            if (markName.contains("_RQ") || markName.contains("_YJ") || markName.contains("_NAME") || markName.contains("_MC")) {//普通文本替换
                replaceBookMarkText(mark, value);
            } else if (markName.contains("_QZ")) {
                String imagePath = value;
                if (imagePath.indexOf("<TOTEXT>") == 0) {
                    //如果是中文签名,直接替换
                    imagePath = imagePath.replaceAll("<TOTEXT>", "");
                    mark.setText(imagePath);
                    Cell imageTd = (Cell) mark.getBookmarkStart().getParentNode().getParentNode();//标签-->段落-->单元格
                    imageTd.getCellFormat().setTopPadding(2);
                    imageTd.getCellFormat().setBottomPadding(2);
                    Row imageRow = imageTd.getParentRow();//单元格-->行
                    imageRow.getRowFormat().setHeight(30);//重置图片单元格所在行的高度
                } else {
                    builder.moveToBookmark(markName);
                    File checkFile = new File(imagePath);
                    if (!checkFile.exists() || "".equals(imagePath) || imagePath.indexOf(".") < 0) return;
                    /**  获取图片大小     **/
                    //BufferedImage sourceImg = ImageIO.read(new File(imagePath));
                    //int imageWidth = sourceImg.getWidth();
                    //int imageHeight = sourceImg.getHeight();
                    //int imageWidth = Config.SIGN_PIC_WIDTH;
                    //int imageHeight = Config.SIGN_PIC_HEIGHT;

                    Shape image = new Shape(doc, ShapeType.IMAGE);
                    image.getImageData().setImage(imagePath);
                    image.setWidth(55);
                    image.setHeight(25);
                    Cell imageTd = (Cell) mark.getBookmarkStart().getParentNode().getParentNode();//标签-->段落-->单元格
                    imageTd.getCellFormat().setTopPadding(imgTopPadding);
                    imageTd.getCellFormat().setBottomPadding(imgBottomPadding);
                    //修改，高度已word单元格的高度为准
                    Row imageRow = imageTd.getParentRow();//单元格-->行
                    //image.setHeight(imageRow.getRowFormat().getHeight());
                    imageRow.getRowFormat().setHeight(imgCellSpacing + imageHeight);//重置图片单元格所在行的高度
                    builder.insertNode(image);
                }
            } else {
                String imagePath = value;
                builder.moveToBookmark(markName);
                File checkFile = new File(imagePath);
                if (!checkFile.exists() || "".equals(imagePath) || imagePath.indexOf(".") < 0) return;
                /**  获取图片大小     **/
                //BufferedImage sourceImg = ImageIO.read(new File(imagePath));
                //int imageWidth = sourceImg.getWidth();
                //int imageHeight = sourceImg.getHeight();
                //int imageWidth = Config.SIGN_PIC_WIDTH;
                //int imageHeight = Config.SIGN_PIC_HEIGHT;

                Shape image = new Shape(doc, ShapeType.IMAGE);
                image.getImageData().setImage(imagePath);
                image.setWidth(55);
                image.setHeight(25);
                Cell imageTd = (Cell) mark.getBookmarkStart().getParentNode().getParentNode();//标签-->段落-->单元格
                imageTd.getCellFormat().setTopPadding(imgTopPadding);
                imageTd.getCellFormat().setBottomPadding(imgBottomPadding);
                //修改，高度已word单元格的高度为准
                Row imageRow = imageTd.getParentRow();//单元格-->行
                //image.setHeight(imageRow.getRowFormat().getHeight());
                imageRow.getRowFormat().setHeight(imgCellSpacing + imageHeight);//重置图片单元格所在行的高度
                builder.insertNode(image);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //条形码替换 （表名加ID_）
    private void replaceBookMarkCode(Bookmark mark, String imagePath) {
        try {
            //imagePath格式： D:\WorkSpace\\printDocDir\20220907095800033.png<HIKEY>evec_55281
            String markName = mark.getName();
            builder.moveToBookmark(markName);
            //图片code为
            String imageCode = imagePath.split("<HIKEY>")[1];
            String imageRealPath = imagePath.split("<HIKEY>")[0];
            //条形码
            encode(imageCode, 80, 30, imageRealPath);
            /**  获取图片大小  **/
            BufferedImage sourceImg = ImageIO.read(new File(imageRealPath));
            int imageWidth = sourceImg.getWidth();
            int imageHeight = sourceImg.getHeight();

            Shape image = new Shape(doc, ShapeType.IMAGE);
            image.getImageData().setImage(imageRealPath);
            image.setWidth(imageWidth);
            image.setHeight(imageHeight);
            builder.insertNode(image);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //生成条形码图片
    public void encode(String data, int width, int height, String imgPath) {
        int codeWidth =
                3 +        // start guard
                        (7 * 6) +    // left bars
                        5 +            // middle guard
                        (7 * 6) +    // right bars
                        3;            // end guard
        codeWidth = Math.max(codeWidth, width);
        try {
            BitMatrix bitMatrix = new MultiFormatWriter().encode(data, BarcodeFormat.CODE_128, codeWidth, height, null);
            MatrixToImageWriter.writeToFile(bitMatrix, "png", new File(imgPath));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 普通文本书签值替换
     *
     * @param mark         书签
     * @param replaceValue 替换值
     */
    public void replaceBookMarkText(Bookmark mark, String replaceValue) {

        try {
            //针对日期格式进行处理
            if (CommonTools.isDate(replaceValue) && !replaceValue.contains("至")) {
                SimpleDateFormat cFormat = new SimpleDateFormat("yyyy年MM月dd日");
                SimpleDateFormat eFormat = new SimpleDateFormat("yyyy-MM-dd");
                replaceValue = eFormat.format(DateUtil.parseDate(replaceValue, "yyyy-MM-dd"));
                if ("text_BXSJ".equals(mark.getName())) {
                    replaceValue = cFormat.format(DateUtil.parseDate(replaceValue, "yyyy-MM-dd"));
                }
            }
            mark.setText(replaceValue);
            if (mark.getBookmarkStart().getParentNode().getParentNode() instanceof Cell) {
                //标签-->段落-->单元格
                Cell textTd = (Cell) mark.getBookmarkStart().getParentNode().getParentNode();
                //单元格内容自动换行
                //textTd.getCellFormat().setWrapText(true);
                //textTd.getCellFormat().setFitText(true);
                //textTd.getCellFormat().setBorderAttr(imageHeight, imgBottomPadding);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 图片标签值替换
     *
     * @param mark          书签
     * @param imageResource 图片
     */
    public void doReplaceImageMarkValue(Bookmark mark, Object imageResource) {

        try {
            if (imageResource instanceof String) {
                String imagePath = imageResource.toString();
                //避免签名图片不存在，中文名称替代
                if (imagePath.indexOf("<TOTEXT>") == 0) {
                    //如果是中文签名,直接替换
                    imagePath = imagePath.replaceAll("<TOTEXT>", "");
                    mark.setText(imagePath);
                    //标签-->段落-->单元格
                    Cell imageTd = (Cell) mark.getBookmarkStart().getParentNode().getParentNode();
                    imageTd.getCellFormat().setTopPadding(2);
                    imageTd.getCellFormat().setBottomPadding(2);
                    //单元格-->行
                    Row imageRow = imageTd.getParentRow();
                    //重置图片单元格所在行的高度
                    imageRow.getRowFormat().setHeight(30);
                } else {
                    String markName = mark.getName();
                    builder.moveToBookmark(markName);

                    File checkFile = new File(imagePath);
                    if (!checkFile.exists() || "".equals(imagePath) || !imagePath.contains(".")) {
                        return;
                    }
                    //获取图片大小
                    BufferedImage sourceImg = ImageIO.read(new File(imagePath));
                    int imageWidth01 = (int) (sourceImg.getWidth() * 0.6);
                    int imageHeight01 = (int) (sourceImg.getHeight() * 0.6);
                    //int imageWidth = Config.SIGN_PIC_WIDTH;
                    //int imageHeight = Config.SIGN_PIC_HEIGHT;

                    Shape image = new Shape(doc, ShapeType.IMAGE);
                    image.getImageData().setImage(sourceImg);
                    //image.getImageData().setImage(imagePath);
                    image.setWidth(imageWidth01);
                    image.setHeight(imageHeight01);
                    //标签-->段落-->单元格
                    Cell imageTd = (Cell) mark.getBookmarkStart().getParentNode().getParentNode();
                    imageTd.getCellFormat().setTopPadding(imgTopPadding);
                    imageTd.getCellFormat().setBottomPadding(imgBottomPadding);
                    //修改，高度已word单元格的高度为准
                    //单元格-->行
                    Row imageRow = imageTd.getParentRow();
                    //image.setHeight(imageRow.getRowFormat().getHeight());
                    //image.setWidth(imageTd.getCellFormat().getWidth());
                    //重置图片单元格所在行的高度
                    imageRow.getRowFormat().setHeight(imgCellSpacing + imageHeight01);
                    builder.insertNode(image);
                }
            } else if (imageResource instanceof BufferedImage) {
                String markName = mark.getName();
                builder.moveToBookmark(markName);
                //获取图片大小
                int imageWidth01 = ((BufferedImage) imageResource).getWidth();
                int imageHeight01 = ((BufferedImage) imageResource).getHeight();
                //int imageWidth = Config.SIGN_PIC_WIDTH;
                //int imageHeight = Config.SIGN_PIC_HEIGHT;

                Shape image = new Shape(doc, ShapeType.IMAGE);
                image.getImageData().setImage((BufferedImage) imageResource);
                image.setWidth(imageWidth01);
                image.setHeight(imageHeight01);
                //标签-->段落-->单元格
                Cell imageTd = (Cell) mark.getBookmarkStart().getParentNode().getParentNode();
                imageTd.getCellFormat().setTopPadding(imgTopPadding);
                imageTd.getCellFormat().setBottomPadding(imgBottomPadding);
                imageTd.getCellFormat().setLeftPadding(5f);
                //修改，高度已word单元格的高度为准
                //单元格-->行
                Row imageRow = imageTd.getParentRow();
                //image.setHeight(imageRow.getRowFormat().getHeight());
                //image.setWidth(imageTd.getCellFormat().getWidth());
                //重置图片单元格所在行的高度
                imageRow.getRowFormat().setHeight(imgCellSpacing + imageHeight01);
                builder.insertNode(image);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 复选框生成
     */
    public void doReplaceCheckBoxMarkValue(Bookmark mark, String replaceValue) {

        try {
            if ("1".equals(replaceValue) || "true".equals(replaceValue) || "是".equals(replaceValue)) {
                //勾选
				/*builder.moveToBookmark(mark.getName());
				FormField checkBox = builder.insertCheckBox("", true, 0);
				checkBox.setCheckBoxSize(10);*/
                mark.setText("☑");
            } else {
				/*builder.moveToBookmark(mark.getName());
				FormField checkBox = builder.insertCheckBox("", false, 0);
				checkBox.setCheckBoxSize(10);*/
                mark.setText("□");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 复选框生成<单一字段多个展示>
     */
    public void doReplaceMultiCheckBoxMarkValue(Bookmark mark, String replaceValue) {

        try {
            //解析出具体的单个字选项
            String markName = mark.getName();
            String columnName = markName.substring(markName.indexOf("_") + 1, markName.length());
            String trueColumnName = columnName + "_true";
            String falseColumnName = columnName + "_false";
            if ("true".equals(replaceValue)) {
                builder.moveToBookmark(trueColumnName);
                builder.insertCheckBox("xx", true, 0);
                builder.moveToBookmark(falseColumnName);
                builder.insertCheckBox("xxx", false, 0);
            } else if ("false".equals(replaceValue)) {
                builder.moveToBookmark(trueColumnName);
                builder.insertCheckBox("xx", false, 0);
                builder.moveToBookmark(falseColumnName);
                builder.insertCheckBox("xxx", true, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 修改单元格的内容
     *
     * @param cell      : 单元格对象
     * @param cellValue : 单元格值
     */
    public void doSetCellContent(Cell cell, String cellValue) {

        try {
            cell.removeAllChildren();
            cell.appendChild(new Paragraph(doc));
            cell.getFirstParagraph().appendChild(new Run(doc, cellValue));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 得到填充好数据的表格对象DataTable
     */
    public DataTable getFilledTable(Document doc, String tableName, String[] colNames, List<List<String>> dataList) {
        DataTable visitTb = new DataTable(tableName);
        //1.表格中加入表头
        for (String colName : colNames) {
            visitTb.getColumns().add(colName);
        }
        int colNum = colNames.length;
        for (List<String> data : dataList) {
            //2.填充每一行数据
            DataRow row = visitTb.newRow();
            int size = data.size();
            for (int i = 0; i < size; i++) {
                //2.1填充每一行中的每一列
                row.set(i, data.get(i));
            }
            visitTb.getRows().add(row);
        }
        //3.无数据则添加默认行
        if (visitTb.getRows().getCount() == 0) {
            DataRow row = visitTb.newRow();
            for (int i = 0; i < colNum; i++) {
                row.set(i, "无");
            }
            visitTb.getRows().add(row);
        }
        return visitTb;
    }

    /**
     * 向表格对象中填充数据，并执行合并操作将表格对象填充进文档对象
     */
    public void fillTableValue(Document doc, String tableName, String[] colNames, List<List<String>> dataList) {
        //1.填充并返回填充好数据的表格对象
        DataTable visitTb = getFilledTable(doc, tableName, colNames, dataList);
        try {
            //2.执行填充操作
            doc.getMailMerge().executeWithRegions(visitTb);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 填充表格行数据
     *
     * @param row     表格行
     * @param content 填充内容
     * @author NATSU
     */
    public void fillRow(Row row, List<Object> content) {
        for (int cellIndex = 0; cellIndex < row.getCells().getCount(); cellIndex++) {
            Cell cell = row.getCells().get(cellIndex);
            String value = StringUtil.getObjectValue(content.get(cellIndex));
            Run run = cell.getFirstParagraph().getRuns().get(0);
            if (run != null) {
                run.setText(value);
            } else {
                cell.appendChild(new Paragraph(doc));
                cell.getFirstParagraph().appendChild(new Run(doc, value));
                cell.getLastParagraph().remove();
            }
        }
    }

    /**
     * 主子表数据关联，适用于导出多个"主表表单嵌套子表列表"的情况
     */
    public void setDataRelation(String relationName, DataTable zbTb, DataTable glbTb, String relationField, Document document) {
        DataSet userSet = new DataSet();
        userSet.getTables().add(zbTb);
        userSet.getTables().add(glbTb);
        String[] contCols = {relationField};
        String[] lstCols = {relationField};
        userSet.getRelations().add(new DataRelation(relationName, zbTb, glbTb, contCols, lstCols));
        try {
            document.getMailMerge().executeWithRegions(userSet);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 写入填充好数据的word文件
     */
    public void saveFile(OutputStream out) {
        try {
            doc.save(out, SaveFormat.DOC);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 写入填充好数据的pdf文件
     */
    public void saveFileToPDF(OutputStream out) {
        try {
            doc.save(out, SaveFormat.PDF);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 得到properties配置文件中的值
     */
    private String getValueByPathAndKey(String classPath, String keyName) {
        ResourcePropertySource propertySource = null;
        String value = null;
        try {
            propertySource = new ResourcePropertySource(classPath);
            value = StringUtil.getObjectValue(propertySource.getProperty(keyName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return value;
    }

}