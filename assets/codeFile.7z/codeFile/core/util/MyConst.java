package com.ibms.purchases.util;

import java.util.HashMap;
import java.util.Map;

public class MyConst {

    public final static String contractDataSourceAlias = "IBMS_712S_CONTRACT";//合同管理系统_数据源别名
    public final static String purchasesDataSourceAlias = "IBMS_712S_PURCHASES";//采购管理系统_数据源别名
    public final static String propertyDataSourceAlias = "IBMS_712S_PROPERTY";//资产管理系统_数据源别名
    public final static String supplierDataSourceAlias = "IBMS_712S_SUPPLIER";//供应商管理系统_数据源别名
    public final static String financeDataSourceAlias = "IBMS_712S_FINANCE";//财务管理系统_数据源别名
    public final static String itDataSourceAlias = "IBMS_712S_IT";//IT运维管理系统_数据源别名
    public final static String pmDataSourceAlias = "xmglxt";//项目管理系统_数据源别名
    public final static String systemDataSourceAlias = "tykfpt";//统一开发平台_数据源别名
    public final static String oldoaDataSourceAlias = "oldoa_system";//老OA_数据源别名

    public final static String purchaseClient_Wzwlcg = "物资物料采购";//当前系统描述（用于标记数据来源，不可修改）
    public final static String purchaseOrgName = "物资管理部";//物资管理部组织名称
    public final static String purchaseOrgCode = "J063";//物资管理部组织编码，通用型库存判断（看生产数据修改）

    public final static String xxhzxOrgCode = "Z004";//信息化中心组织编码 - 计算机类，接口判断（看生产数据修改）
    public final static String xxhzxYWLB = "IT运维";
    public final static String ghjxbOrgCode = "J058";//规划建设部组织编码 - 大型设备，接口判断（看生产数据修改）
    public final static String ghjxbYWLB = "其他";
    public final static String cpjyzxOrgCode = "J059";//质量安全环保部组织编码 - 监视和测量设备，接口判断（看生产数据修改）
    public final static String cpjyzxYWLB = "监视和测量设备";

    public final static String materialPurchase = "物资物料采购";//一级库管理，数据来源（不可修改）
    public final static String outSourcingPurchase = "外包外协采购";//外包外协采购，数据来源（不可修改）
    public final static String inStorageStartAction = "UserTask_PnCVaDt";//入库流程第一个节点
    public final static String badobjHandleStartAction = "UserTask_o1GKGKH";//不合格品处理流程第一个节点
    public final static String fixedAssetsPurchase = "资产采购";//资产采购

    public final static String assetsPurchase = "采购系统";//采购系统


    //合同类型-项目类型，转换
    public final static Map<String, String> contractType = new HashMap<String, String>() {{
        put("M", "民品物资");
        put("J", "军品物资");
        put("Y", "科研物资");
        put("Q", "其他物资");
    }};

    public final static String cglxCH = "采购长海库存";//采购类型_转长海采购

    public final static String yqybType = "仪器仪表类";//入所复验_仪器仪表类_子流程类型
    public final static String yqybUserTask1 = "UserTask_EWWMujS";//入所复验_仪器仪表类_子流程第一个节点
    public final static String yqybUserTask2 = "UserTask_1kgyfet";//入所复验_仪器仪表类_子流程第二个节点
    public final static String yqybUserTask3 = "UserTask_1ciufq0";//入所复验_仪器仪表类_子流程第三个节点
    public final static String yqybUserTask4 = "EndEvent_1y23mlt";//入所复验_仪器仪表类_子流程结束节点

    public final static String sccpType = "生产产品类";//入所复验_生产产品类_子流程类型
    public final static String sccpUserTask1 = "UserTask_zUOj9Ts";//入所复验_生产产品类_子流程第一个节点
    public final static String sccpUserTask2 = "UserTask_06r8fxs";//入所复验_生产产品类_子流程第二个节点
    public final static String sccpUserTask3 = "UserTask_06r8fxs";//入所复验_生产产品类_子流程第三个节点
    public final static String sccpUserTask4 = "EndEvent_1l312ck";//入所复验_生产产品类_子流程结束节点
}