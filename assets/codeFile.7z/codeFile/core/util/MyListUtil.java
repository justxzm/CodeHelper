package com.ibms.purchases.util;

import java.util.*;
import java.util.function.Function;

public class MyListUtil {

    /**
     *  @desc : 多行文本值换行
     *  @createDate : 2023/3/31 19:52
     */
    public static String toWrapText(List<String> textList){
        String res = "";
        if(CommonTools.isNotEmptyList(textList)){
            for(String text:textList){
                res += text + "\n";
            }
        }
        return res;
    }

    /**
     *  @desc : List转Map
     *  @createDate : 2023/9/5 9:05
     */
    public static Map<String,Map<String,Object>> list2Map(List<Map<String,Object>> dataList, String fieldName){
        Map<String,Map<String,Object>> resMap = new HashMap<>();
        if(CommonTools.isNotEmptyList(dataList)){
            for(Map<String,Object> dataMap:dataList){
                String fieldVal = CommonTools.Obj2String(dataMap.get(fieldName));
                resMap.put(fieldVal,dataMap);
            }
        }
        return resMap;
    }
    public static Map<String,Object> list2Map(List<Map<String,Object>> dataList, String keyName, String valName){
        Map<String,Object> resMap = new HashMap<>();
        if(CommonTools.isNotEmptyList(dataList)){
            for(Map<String,Object> dataMap:dataList){
                String key = CommonTools.Obj2String(dataMap.get(keyName));
                String val = CommonTools.Obj2String(dataMap.get(valName));
                resMap.put(key,val);
            }
        }
        return resMap;
    }
    public static <T> Map<String,T> list2Map(List<T> dataList, Function myFunc) {
        Map<String,T> resMap = new HashMap<>();
        if (CommonTools.isNotEmptyList(dataList)) {
            dataList.forEach(dataMap -> resMap.put(CommonTools.Obj2String(myFunc.apply(dataMap)),dataMap));
        }
        return resMap;
    }

    /**
     *  @desc : List字段取值
     *  @createDate : 2023/10/23 11:21
     */
    public static <T> Set<String> getFieldValSet(List<T> dataList, Function myFunc) {
        Set<String> valSet = new HashSet<>();
        if (CommonTools.isNotEmptyList(dataList)) {
            dataList.forEach(dataMap -> valSet.add(CommonTools.Obj2String(myFunc.apply(dataMap))));
        }
        return valSet;
    }
    public static Set<String> getFieldValSet(List<Map<String, Object>> dataList, String fieldName) {
        Set<String> valSet = new HashSet<>();
        if (CommonTools.isNotEmptyList(dataList)) {
            dataList.forEach(dataMap -> valSet.add(CommonTools.Obj2String(dataMap.get(fieldName))));
        }
        return valSet;
    }
    public static String getFieldVals(List<Map<String, Object>> dataList, String fieldName) {
        return MySetUtil.toString(getFieldValSet(dataList, fieldName), ",");
    }

    public static String toString(List<String> strList, String splitMark){
        final String[] res = {""};
        splitMark = CommonTools.Obj2String(splitMark);
        if(CommonTools.isNotEmptyList(strList)){
            String finalSplitMark = splitMark;
            strList.stream().forEach(item->{
                res[0] += finalSplitMark + item;
            });
            res[0] = res[0].substring(1);
        }
        return res[0];
    }
}