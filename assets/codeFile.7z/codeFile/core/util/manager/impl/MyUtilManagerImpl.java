package com.ibms.purchases.util.manager.impl;

import cn.hutool.core.util.NumberUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.ibms.common.util.common.BeanUtils;
import com.ibms.common.util.common.HttpUtil;
import com.ibms.common.util.common.UserContextUtil;
import com.ibms.common.util.date.DateUtil;
import com.ibms.common.util.file.FileUtil;
import com.ibms.common.util.file.LocalFileUtil;
import com.ibms.common.util.file.ZipUtil;
import com.ibms.common.util.string.StringUtil;
import com.ibms.common.web.response.Response;
import com.ibms.db.datasource.util.DataSourceUtil;
import com.ibms.db.id.UniqueIdUtil;
import com.ibms.project.common.constants.DataSourceConstant;
import com.ibms.purchases.fileExport.manager.impl.FileExportManagerImpl;
import com.ibms.purchases.service.IPurchaseBpmnService;
import com.ibms.purchases.service.IPurchaseFileService;
import com.ibms.purchases.service.IPurchaseSysService;
import com.ibms.purchases.util.*;
import com.ibms.purchases.util.lscPrint.service.LscPrintService;
import com.ibms.purchases.util.manager.MyUtilManager;
import com.ibms.rest.bpmn.model.StartRequestActionDto;
import com.ibms.rest.bpmn.model.TaskRequestActionDto;
import com.ibms.rest.file.model.FileStorageConfig;
import com.ibms.rest.file.model.SunFile;
import com.ibms.rest.mdm.model.SysOrg;
import com.ibms.rest.mdm.model.SysUser;
import com.ibms.rest.mdm.model.UserPosition;
import com.ibms.rest.project.print.model.PrintInfo;
import com.ibms.rest.project.print.model.PrintResult;
import com.ibms.rest.service.FileService;
import com.ibms.rest.sys.model.SysParameter;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.*;


/**
 * 工具接口
 */
@Service
public class MyUtilManagerImpl implements MyUtilManager {

    @Resource
    private JdbcTemplate jdbcTemplate;
    @Resource
    private IPurchaseSysService purchaseSysService;
    @Resource
    private IPurchaseBpmnService purchaseBpmnService;
    @Resource
    private IPurchaseFileService purchaseFileService;
    @Resource
    private FileExportManagerImpl fileExportManagerImpl;
    @Resource
    private LscPrintService lscPrintService;

    @Override//更新流程数据状态
    public Response<Void> updateFlowStatus(String bussinessKey,
                                           String tableName, String fieldName, String status,
                                           String subTableName, String subFieldName, String subStatus) {
        if (!"null".equals(tableName) && !"null".equals(fieldName) && !"null".equals(status)) {
            String updateSql = "UPDATE " + tableName + " SET " + fieldName + "=? WHERE ID_=?";
            jdbcTemplate.update(updateSql, new Object[]{status, bussinessKey});
        }
        if (!"null".equals(subTableName) && !"null".equals(subFieldName) && !"null".equals(subStatus)) {
            String subUpdateSql = "UPDATE " + subTableName + " SET " + subFieldName + "=? WHERE REF_ID_=?";
            jdbcTemplate.update(subUpdateSql, new Object[]{subStatus, bussinessKey});
        }
        return new Response<Void>().success();
    }

    @Override//更新表单数据状态
    public Response<Void> updateStatus(String ids, String tableName, String fieldNameStr, String statusStr,
                                       String refIds, String subTableName, String subFieldName, String subStatus) {
        if (StringUtil.isNotEmpty(ids) && StringUtil.isNotEmpty(tableName) && StringUtil.isNotEmpty(fieldNameStr) && StringUtil.isNotEmpty(statusStr)) {
            String setSql = " SET ";
            for (String fieldName : fieldNameStr.split(",")) {
                setSql += fieldName + "=?,";
            }
            setSql = setSql.substring(0, setSql.length() - 1);
            String updateSql = "UPDATE " + tableName + setSql + " WHERE ID_ IN ('" + ids.replace(",", "','") + "')";
            jdbcTemplate.update(updateSql, statusStr.split(","));
        }
        if (StringUtil.isNotEmpty(refIds) && StringUtil.isNotEmpty(subTableName) && StringUtil.isNotEmpty(subFieldName) && StringUtil.isNotEmpty(subStatus)) {
            String subUpdateSql = "UPDATE " + subTableName + " SET " + subFieldName + "=? WHERE REF_ID_ IN ('" + refIds.replace(",", "','") + "')";
            jdbcTemplate.update(subUpdateSql, new Object[]{subStatus});
        }
        return new Response<Void>().success();
    }

    @Override//流水号
    public String getNextSerialNumber(String alias) {
        String res = purchaseSysService.getNextSerialNumber(alias, HttpUtil.getClientNum());
        return res;
    }

    @Override//流水号
    public String getNextSerialNumberOrg(String alias) {
        return this.getNextSerialNumberOrg(alias, UserContextUtil.getCurrentUserOrgCode());
    }

    @Override//流水号
    public String getNextSerialNumberOrg(String alias, String orgCode) {
        String res = this.getNextSerialNumber(alias);
        if (StringUtil.isNotEmpty(res)) {
            String[] arr = res.split("-");
            res = arr[0] + "-" + orgCode;
            for (int i = 1, size = arr.length; i < size; i++) {
                res += "-" + arr[i];
            }
        }
        return res;
    }

    @Override//批量启动流程
    public Response<Void> batchStartFlow(List<JSONObject> paramList) {
        //批量启动流程
        List<StartRequestActionDto> flowList = new ArrayList<>();
        for (JSONObject params : paramList) {
            String businessKey = params.getString("businessKeys");//表单ID
            String startUserCode = params.getString("startUserCode");//发起人Code
            String defId = params.getString("defId");//流程定义ID
            String firstNodeKey = params.getString("firstNodeKey");//第一个节点Key
            StartRequestActionDto dto = new StartRequestActionDto();
            dto.setProcDefId(defId);
            dto.setBusinessKey(businessKey);
            dto.setStartUserCode(startUserCode);
            Map<String, Set<String>> bpmIdentityIds = new HashMap<>(1);
            bpmIdentityIds.put(firstNodeKey, MyStringUtil.toSet(startUserCode, ","));//设置第一个节点的执行人
            dto.setBpmIdentityIds(bpmIdentityIds);
            //false：不跳过，true：按流程配置执行
            if (params.containsKey("skipFirstNode")) {
                dto.setSkipFirstNode(params.getBoolean("skipFirstNode"));
            } else {
                dto.setSkipFirstNode(true);
            }
            flowList.add(dto);
        }
        try {
            purchaseBpmnService.startApiForBatch(flowList);
        } catch (Exception e) {
            e.printStackTrace();
            return new Response<Void>().failure(e.getMessage());
        }
        return new Response<Void>().success();
    }

    @Override//批量启动流程
    public Response<Void> startFlow(JSONObject param) {
        List<JSONObject> paramList = new ArrayList<>();
        paramList.add(param);
        return this.batchStartFlow(paramList);
    }

    //判断用户是否为某组织负责人
    @Override
    public Response<Boolean> isUserChargeOrgByCode(String userCode, String orgCode, String orgIsDelete) {
        boolean isUserChargeOrg = false;
        List<UserPosition> positions = purchaseSysService.getOrgChargeByCode(orgCode, orgIsDelete);
        if (CommonTools.isNotEmptyList(positions)) {
            for (UserPosition position : positions) {
                if (position.getUserCode().equals(userCode)) {
                    isUserChargeOrg = true;
                    break;
                }
            }
        }
        return (new Response<Boolean>()).success(isUserChargeOrg);
    }

    @Override//处理流程回填审批意见
    public String dealWithFlowOpinion(String opinion) {
        String res = "";
        if (StringUtil.isNotEmpty(opinion) && opinion.contains("：")) {
            res = opinion.split("：")[1];
        }
        return res;
    }

    @Override//获得流程审批意见信息
    public Map<String, Map<String, Object>> getFlowOpinionInfo(String bussinessKey) {
        Map<String, Map<String, Object>> opinionInfo = new HashMap<>();
        String querySql = "SELECT T2.TASK_KEY_,T2.TASK_NAME_,T2.STATUS_,T2.STATUS_VAL_," +
                "T2.AUDITOR_,T2.AUDITOR_CODE_,T2.AUDITOR_NAME_,T2.AUDITOR_ORG_CODE_,T2.AUDITOR_ORG_NAME_," +
                "T2.OPINION_,T2.COMPLETE_TIME_ " +
                "FROM BPM_PRO_INST_HI T1 INNER JOIN BPM_CHECK_OPINION T2 ON T1.ID_=T2.PROC_INST_ID_ " +
                "WHERE T1.BUSINESS_KEY_='" + bussinessKey + "' ORDER BY T2.SN_";
        List<Map<String, Object>> dataList = MyJdbcUtil.getJdbcTemplate(DataSourceConstant.system).queryForList(querySql);
        if (CommonTools.isNotEmptyList(dataList)) {
            opinionInfo = MyListUtil.list2Map(dataList, "TASK_KEY_");
        }
        return opinionInfo;
    }

    @Override//获得跳过节点的审批人或意见
    public String getSkipFlowNodeInfo(String infoType, String fieldVal, Map<String, Map<String, Object>> opinionInfo, String nodeKeyPath, String curNodeKey) {
        if (StringUtil.isEmpty(fieldVal)) {
            if (opinionInfo != null && opinionInfo.size() > 0) {
                boolean startSearch = false;//开始追溯
                String[] nodeKeyArr = nodeKeyPath.split(",");
                for (String nodeKey : nodeKeyArr) {
                    if (opinionInfo.containsKey(nodeKey) && (curNodeKey.equals(nodeKey) || startSearch)) {
                        startSearch = true;
                        Map<String, Object> opinion = opinionInfo.get(nodeKey);
                        if (!"skip".equals(opinion.get("STATUS_"))) {
                            if ("userCode".equals(infoType)) {
                                fieldVal = CommonTools.Obj2String(opinion.get("AUDITOR_CODE_"));
                            } else if ("opinion".equals(infoType)) {
                                fieldVal = CommonTools.Obj2String(opinion.get("OPINION_"));
                                if ("发起流程".equals(fieldVal) || "提交申请信息".equals(fieldVal)) {
                                    fieldVal = "同意";
                                }
                            } else if ("date".equals(infoType)) {
                                fieldVal = CommonTools.Obj2String(opinion.get("COMPLETE_TIME_"));
                                fieldVal = fieldVal.length() > 10 ? fieldVal.substring(0, 10) : fieldVal;
                            } else if ("time".equals(infoType)) {
                                fieldVal = CommonTools.Obj2String(opinion.get("COMPLETE_TIME_"));
                                fieldVal = fieldVal.length() > 19 ? fieldVal.substring(0, 19) : fieldVal;
                            }
                            break;
                        }
                    }
                }
            }
        } else {
            if ("opinion".equals(infoType)) {
                fieldVal = this.dealWithFlowOpinion(fieldVal);
            }
        }
        return CommonTools.Obj2String(fieldVal);
    }

    @Override//根据用户CODE得到签章文件流
    public byte[] getUserSignatureBlob(String userCode) {
        byte[] fileBlob = null;
        if (StringUtil.isNotEmpty(userCode)) {
            SysUser user = purchaseSysService.getByUserAccount(userCode, "active");
            if (user != null && StringUtil.isNotEmpty(user.getSignaturePath())) {
                try {
                    SunFile sunFile = purchaseFileService.getFileById(user.getSignaturePath());
                    if (sunFile != null) {
                        fileBlob = sunFile.getFileBlob();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return fileBlob;
    }

    @Override//根据组织CODE得到签章文件流
    public byte[] getOrgSignatureBlob(String orgCode) {
        byte[] fileBlob = null;
        if (StringUtil.isNotEmpty(orgCode)) {
            SysOrg org = purchaseSysService.getByOrgCode(orgCode);
            if (org != null && StringUtil.isNotEmpty(org.getSignaturePath())) {
                try {
                    SunFile sunFile = purchaseFileService.getFileById(org.getSignaturePath());
                    if (sunFile != null) {
                        fileBlob = sunFile.getFileBlob();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return fileBlob;
    }

    @Override//根据用户CODE得到红章文件流
    public byte[] getUserRedSignatureBlob(String userCode) {
        byte[] fileBlob = null;
        if (StringUtil.isNotEmpty(userCode)) {
            String sql = "select * from W_CGHZSJWHB where F_RYCODE = '" + userCode + "'";
            List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
            if (list.size() > 0) {
                String f_hz = JSON.parse(list.get(0).get("F_HZ").toString()).toString();
                JSONArray jsonArray = JSONArray.parseArray(f_hz);
                JSONObject obj = jsonArray.getJSONObject(0);
                String fileId = obj.getString("fileId");
                try {
                    SunFile sunFile = purchaseFileService.getFileById(fileId);
                    if (sunFile != null) {
                        fileBlob = sunFile.getFileBlob();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                fileBlob = this.getUserSignatureBlob(userCode);
            }
        }
        return fileBlob;
    }

    @Override//获得条形码文件流
    public byte[] getBarCodeBlob(String value, int width, int height) {
        byte[] imgBlob = null;
        int codeWidth = 3 +          // start guard
                (7 * 6) +    // left bars
                5 +          // middle guard
                (7 * 6) +    // right bars
                3;           // end guard
        width = Math.max(codeWidth, width);
        try {
            String tmpDirPath = getLocalTmpDirPath();
            String tmpFilePath = tmpDirPath + File.separator + DateUtil.getCurrentDateStr("yyyyMMddHHmmssSSS") + ".png";
            BitMatrix bitMatrix = new MultiFormatWriter().encode(value, BarcodeFormat.CODE_128, width, height, null);
            MatrixToImageWriter.writeToFile(bitMatrix, "png", new File(tmpFilePath));
            imgBlob = FileUtil.readByte(tmpFilePath);
            FileUtil.deleteDir(new File(tmpDirPath));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return imgBlob;
    }

    @Override//推立思辰打印
    public Response<Void> sendToLscPrint(String funcName, String fileName, String filePath) {
        PrintInfo printInfo = new PrintInfo();
        printInfo.setJobName(UserContextUtil.getCurrentUserName() + funcName);
        PrintResult res = lscPrintService.sendToPrint(printInfo, fileName, filePath);
        if (PrintResult.PRINTAPPLY_FAIL.equals(res.getResult())) {
            //throw new RuntimeException(res.getMsg());//抛出异常，打印错误日志
            return new Response<Void>().failure(res.getMsg());
        } else {
            return new Response<Void>().success(res.getMsg());
        }
    }

    @Override//生成当前用户磁盘临时目录
    public String getLocalTmpDirPath() {
        String localPath = purchaseFileService.getStorageConfByName("defaultDisc").getRootDirectory();
        String dirUUID = UserContextUtil.getCurrentUserCode() + "_" + DateUtil.getCurrentDateStr("yyyyMMddHHmmssSSS");
        String tempDir = localPath + File.separator + "temp" + File.separator + dirUUID;
        File tempPathDir = new File(tempDir);
        tempPathDir.mkdirs();
        return tempDir;
    }

    @Override//从模板导出PDF
    public Response<Void> exportMyPDF(String expFileName, String templateFilePath,
                                      Map<String, Object> txtFillMap, Map<String, byte[]> imgFillMap,
                                      HttpServletRequest request, HttpServletResponse response) {
        return this.exportMyPDF(expFileName, templateFilePath, txtFillMap, imgFillMap, null, request, response);
    }

    public Response<Void> exportMyPDF(String expFileName, String templateFilePath,
                                      Map<String, Object> txtFillMap, Map<String, byte[]> imgFillMap, List<byte[]> pdfAddInfo,
                                      HttpServletRequest request, HttpServletResponse response) {
        expFileName = expFileName + System.currentTimeMillis() + ".pdf";
        String tempDir = this.getLocalTmpDirPath();
        String filePath = tempDir + File.separator + expFileName;
        Response<Void> res = new Response<Void>().success();
        try {
            ClassPathResource resource = new ClassPathResource(templateFilePath);//加载模板
            MyPdfUtil.mergeData(resource.getInputStream(), filePath, txtFillMap, imgFillMap);//填充数据
            //追加pdf页
            if (CommonTools.isNotEmptyList(pdfAddInfo)) {
                pdfAddInfo.add(0, FileUtil.readByte(filePath));
                FileUtil.deleteFile(filePath);
                FileUtil.byte2File(filePath, this.fileExportManagerImpl.mergePdfFiles(pdfAddInfo));
            }
            //推立思辰接口、下载
            boolean lscPrint = CommonTools.obj2boolean(request.getParameter("lscPrint"));
            if (lscPrint) {
                res = this.sendToLscPrint(expFileName.substring(0, expFileName.lastIndexOf(".")), expFileName, filePath);
            } else {
                LocalFileUtil.downLoadFileByBlob(request, response, filePath, expFileName);//响应下载
            }
            //清理临时文件
            FileUtil.deleteDir(new File(tempDir));
        } catch (IOException e) {
            e.printStackTrace();
            res = new Response<Void>().failure(e.getMessage());
        }
        return res;
    }

    //从模板导出PDF(多个-zip)
    @Override
    public Response<Void> exportMyPDFZIP(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                         List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList,
                                         HttpServletRequest request, HttpServletResponse response) {
        return this.exportMyPDFZIP_add(zipName, expFileNameList, templateFilePathList, txtFillList, imgFillList, null, null, request, response);
    }

    public Response<Void> exportMyPDFZIP_add2Zip(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                                 List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList,
                                                 Map<String, byte[]> add2ZipMap,
                                                 HttpServletRequest request, HttpServletResponse response) {
        return this.exportMyPDFZIP_add(zipName, expFileNameList, templateFilePathList, txtFillList, imgFillList, null, add2ZipMap, request, response);
    }

    public Response<Void> exportMyPDFZIP_add2Pdf(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                                 List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList,
                                                 List<List<byte[]>> add2PdfList,
                                                 HttpServletRequest request, HttpServletResponse response) {
        return this.exportMyPDFZIP_add(zipName, expFileNameList, templateFilePathList, txtFillList, imgFillList, add2PdfList, null, request, response);
    }

    public Response<Void> exportMyPDFZIP_add(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                             List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList,
                                             List<List<byte[]>> add2PdfList, Map<String, byte[]> add2ZipMap,
                                             HttpServletRequest request, HttpServletResponse response) {
        Response<Void> res = new Response<Void>().success();
        try {
            String folderName = zipName + System.currentTimeMillis();
            String fileName = URLEncoder.encode(folderName + ".zip", "utf-8");
            String tempDir = this.getLocalTmpDirPath();
            //压缩文件夹位置
            String filePath = tempDir + File.separator + folderName;
            File tempPathDir = new File(filePath);
            tempPathDir.mkdirs();

            for (int i = 1; i <= txtFillList.size(); i++) {
                String expFileName = expFileNameList.get(i - 1);
                String templateFilePath = templateFilePathList.get(i - 1);
                ClassPathResource resource = new ClassPathResource(templateFilePath);
                Map<String, Object> txtFillMap = txtFillList.get(i - 1);
                Map<String, byte[]> imgFillMap = imgFillList.get(i - 1);
                String tempFileName = filePath + File.separator + expFileName + i + ".pdf";
                MyPdfUtil.mergeData(resource.getInputStream(), tempFileName, txtFillMap, imgFillMap);
                //向每一个PDF追加对应页
                if (CommonTools.isNotEmptyList(add2PdfList) && add2PdfList.size() > i) {
                    List<byte[]> pdfAddInfo = add2PdfList.get(i - 1);
                    if (CommonTools.isNotEmptyList(pdfAddInfo)) {
                        pdfAddInfo.add(0, FileUtil.readByte(tempFileName));
                        FileUtil.deleteFile(tempFileName);
                        FileUtil.byte2File(tempFileName, this.fileExportManagerImpl.mergePdfFiles(pdfAddInfo));
                    }
                }
            }
            //向ZIP追加PDF
            if (add2ZipMap != null && add2ZipMap.size() > 0) {
                for (String expFileName : add2ZipMap.keySet()) {
                    String tempFilePath = filePath + File.separator + expFileName + ".pdf";
                    FileUtil.byte2File(tempFilePath, add2ZipMap.get(expFileName));
                }
            }
            ZipUtil.zip(filePath, "GBK", true);
            //压缩文件路径
            String zipPath = filePath + ".zip";
            //推立思辰接口、下载
            boolean lscPrint = CommonTools.obj2boolean(request.getParameter("lscPrint"));
            if (lscPrint) {
                res = this.sendToLscPrint(zipName, zipName + ".zip", zipPath);
            } else {
                response.addHeader("Access-Control-Allow-Origin", "*");
                response.addHeader("Access-Control-Expose-Headers", "Content-Disposition");
                response.setContentType("application/octet-stream; charset=UTF-8");
                response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
                BufferedInputStream in = new BufferedInputStream(new FileInputStream(zipPath));
                BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
                byte[] buffer = new byte[2048];
                int len = 0;
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }
                out.flush();
                out.close();
                in.close();
            }
            //清理临时文件
            FileUtil.deleteDir(new File(tempDir));
        } catch (IOException e) {
            e.printStackTrace();
            res = new Response<Void>().failure(e.getMessage());
        }
        return res;
    }

    //从模板导出PDF(多个-合并的PDF)
    @Override
    public Response<Void> exportMergePDF(String pdfName, List<String> expFileNameList, List<String> templateFilePathList, List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList, HttpServletRequest request, HttpServletResponse response) {
        Response<Void> res = new Response<Void>().success();
        try {
            String exportPdfName = pdfName + System.currentTimeMillis() + ".pdf";
            String tempDir = this.getLocalTmpDirPath();
            List<byte[]> bytesList = new ArrayList<>();
            for (int i = 1; i <= txtFillList.size(); i++) {
                String expFileName = expFileNameList.get(i - 1);
                String templateFilePath = templateFilePathList.get(i - 1);
                ClassPathResource resource = new ClassPathResource(templateFilePath);
                Map<String, Object> txtFillMap = txtFillList.get(i - 1);
                Map<String, byte[]> imgFillMap = imgFillList.get(i - 1);
                String tempFileName = tempDir + File.separator + expFileName + i + ".pdf";
                MyPdfUtil.mergeData(resource.getInputStream(), tempFileName, txtFillMap, imgFillMap);
                File file = new File(tempFileName);
                if (file.exists()) {
                    byte[] pdfFileData = FileUtil.readByte(tempFileName);
                    bytesList.add(pdfFileData);
                }
            }
            //合并pdf
            byte[] outBytes = this.fileExportManagerImpl.mergePdfFiles(bytesList);
            //推立思辰接口、下载
            boolean lscPrint = CommonTools.obj2boolean(request.getParameter("lscPrint"));
            if (lscPrint) {
                String targetFilePath = tempDir + File.separator + exportPdfName;
                LocalFileUtil.writeByte(targetFilePath, outBytes);
                res = this.sendToLscPrint(exportPdfName.substring(0, exportPdfName.lastIndexOf(".")), exportPdfName, targetFilePath);
            } else {
                LocalFileUtil.downtFileByBlob(request, response, exportPdfName, outBytes);
            }
            //清理临时文件
            FileUtil.deleteDir(new File(tempDir));
        } catch (Exception e) {
            e.printStackTrace();
            res = new Response<Void>().failure(e.getMessage());
        }
        return res;
    }

    @Override//从模板导出PDF(多个-合并的PDF)
    public Response<Void> exportMergePDF(String pdfName, byte[] pdfBytes, HttpServletRequest request, HttpServletResponse response) {
        List<byte[]> pdfBytesList = new ArrayList<>();
        pdfBytesList.add(pdfBytes);
        return this.exportMergePDF(pdfName, pdfBytesList, request, response);
    }

    public Response<Void> exportMergePDF(String pdfName, List<byte[]> pdfBytesList, HttpServletRequest request, HttpServletResponse response) {
        Response<Void> res = new Response<Void>().success();
        try {
            pdfName = pdfName + System.currentTimeMillis() + ".pdf";
            String tempDir = this.getLocalTmpDirPath();
            //合并pdf
            byte[] outBytes = this.fileExportManagerImpl.mergePdfFiles(pdfBytesList);
            //推立思辰接口、下载
            boolean lscPrint = CommonTools.obj2boolean(request.getParameter("lscPrint"));
            if (lscPrint) {
                String targetFilePath = tempDir + File.separator + pdfName;
                LocalFileUtil.writeByte(targetFilePath, outBytes);
                res = this.sendToLscPrint(pdfName.substring(0, pdfName.lastIndexOf(".")), pdfName, targetFilePath);
            } else {
                LocalFileUtil.downtFileByBlob(request, response, pdfName, outBytes);
            }
            //清理临时文件
            FileUtil.deleteDir(new File(tempDir));
        } catch (Exception e) {
            e.printStackTrace();
            res = new Response<Void>().failure(e.getMessage());
        }
        return res;
    }

    @Override//获取数据字典信息
    public Set<String> getDicValInfoSet(String dicAlias, String clientNum) {
        Set<String> dicInfoSet = new LinkedHashSet<>();
        List<Map<String, Object>> dicNodeList = this.getDicInfoList(dicAlias, clientNum);
        dicNodeList.stream().forEach(dicNode -> {
            String dicKey = CommonTools.Obj2String(dicNode.get("KEY_"));
            dicInfoSet.add(dicKey);
        });
        return dicInfoSet;
    }

    @Override//获取数据字典信息
    public Set<String> getDicNameInfoSet(String dicAlias, String clientNum) {
        Set<String> dicInfoSet = new LinkedHashSet<>();
        List<Map<String, Object>> dicNodeList = this.getDicInfoList(dicAlias, clientNum);
        dicNodeList.stream().forEach(dicNode -> {
            String dicName = CommonTools.Obj2String(dicNode.get("NAME_"));
            dicInfoSet.add(dicName);
        });
        return dicInfoSet;
    }

    @Override//获取数据字典信息
    public Map<String, Object> getDicValInfoMap(String dicAlias, String clientNum) {
        Map<String, Object> dicInfoMap = new HashMap<>();
        List<Map<String, Object>> dicNodeList = this.getDicInfoList(dicAlias, clientNum);
        dicNodeList.stream().forEach(dicNode -> {
            String dicKey = CommonTools.Obj2String(dicNode.get("KEY_"));
            String dicName = CommonTools.Obj2String(dicNode.get("NAME_"));
            dicInfoMap.put(dicKey, dicName);
        });
        return dicInfoMap;
    }

    @Override//获取数据字典信息
    public Map<String, Object> getDicNameInfoMap(String dicAlias, String clientNum) {
        Map<String, Object> dicInfoMap = new HashMap<>();
        List<Map<String, Object>> dicNodeList = this.getDicInfoList(dicAlias, clientNum);
        dicNodeList.stream().forEach(dicNode -> {
            String dicName = CommonTools.Obj2String(dicNode.get("NAME_"));
            String dicKey = CommonTools.Obj2String(dicNode.get("KEY_"));
            dicInfoMap.put(dicName, dicKey);
        });
        return dicInfoMap;
    }

    @Override//获取数据字典信息
    public Map<String, Object> getDicAllInfoMap(String dicAlias, String clientNum) {
        Map<String, Object> allDicInfoMap = new HashMap<>();
        Map<String, Object> dicInfoMap = this.getDicValInfoMap(dicAlias, clientNum);
        for (String key : dicInfoMap.keySet()) {
            allDicInfoMap.put(key, dicInfoMap.get(key));
            allDicInfoMap.put(CommonTools.Obj2String(dicInfoMap.get(key)), key);
        }
        return allDicInfoMap;
    }

    //获取数据字典信息
    private List<Map<String, Object>> getDicInfoList(String dicAlias, String clientNum) {
        JdbcTemplate assembly = DataSourceUtil.getJdbcTempByDsAlias(MyConst.systemDataSourceAlias);
        String querySql = "SELECT t1.KEY_,t1.NAME_ FROM FORM_DATA_DIC t1 "
                + "WHERE t1.TYPE_KEY_='" + dicAlias + "' AND t1.CLIENT_NUM_='" + clientNum + "' "
                + "ORDER BY t1.SN_";
        List<Map<String, Object>> dicInfoList = assembly.queryForList(querySql);
        return dicInfoList;
    }

    @Override//数据迁移hadoop文件处理
    public Response<Void> dealWithHadoopFile(String tableName, String fieldName, String dataSource) {
        //查询待处理历史数据
        JdbcTemplate jdbcTemplate = null;
        if (StringUtil.isEmpty(dataSource)) {
            jdbcTemplate = this.jdbcTemplate;
        } else {
            jdbcTemplate = MyJdbcUtil.getJdbcTemplate(dataSource);
        }
        String querySql = "SELECT ID_," + fieldName + " FROM " + tableName + " WHERE NVL(" + fieldName + ",'')!='' AND INSTR(" + fieldName + ",'hdfs####')>0";
        List<Map<String, Object>> dataList = jdbcTemplate.queryForList(querySql);
        if (CommonTools.isNotEmptyList(dataList)) {
            String errMsg = null;
            //获取hadoop文件上传信息
            FileStorageConfig fileStorageConfig = purchaseFileService.getStorageConfByName("712Hdfs");
            String hdfsPathServer = "hdfs://" + fileStorageConfig.getUploadPath() + ":" + fileStorageConfig.getPort() + fileStorageConfig.getRootDirectory();
            String tmpFilePath = getLocalTmpDirPath();
            JSONObject params = new JSONObject();
            params.put("folderId", "99");
            params.put("securityLevel", "0");
            try {
                for (Map<String, Object> dataMap : dataList) {
                    String id = CommonTools.Obj2String(dataMap.get("ID_"));
                    String fileInfo = CommonTools.Obj2String(dataMap.get(fieldName));
                    String fileName = fileInfo.split("####")[1];
                    String filePath = fileInfo.split("####")[2];
                    String remotePath = hdfsPathServer + filePath;
                    String localPath = tmpFilePath + File.separator + DateUtil.getCurrentDateStr("yyyyMMddHHmmssSSS") + fileName;
                    //下载到本地
                    HDFSFileUtil.copy(hdfsPathServer, remotePath, localPath);
                    //上传到平台
                    File localFile = new File(localPath);
                    MultipartFile multipartFile = FileUtil.fileToMultipartFile(localFile);
                    String fileId = UniqueIdUtil.getUniqueIdString();
                    params.put("id", fileId);
                    SunFile sunFile = purchaseFileService.customUpload(multipartFile, params.toJSONString());
                    //更新附件字段
                    if (BeanUtils.isNotEmpty(sunFile)) {
                        JSONArray fileArr = new JSONArray();
                        JSONObject fileObj = new JSONObject();
                        fileObj.put("id", sunFile.getId());
                        fileObj.put("name", sunFile.getName());
                        fileObj.put("uid", fileId);
                        fileObj.put("creatorName", sunFile.getCreatorName());
                        fileObj.put("createTime", DateUtil.format(sunFile.getCreateTime(), "yyyy-MM-dd HH:mm:ss"));
                        fileObj.put("isDownload", "false");
                        fileObj.put("success", "success");
                        fileObj.put("size", sunFile.getSize());
                        fileObj.put("securityLevel", sunFile.getSecurityLevel());
                        fileObj.put("securityTerm", "无");
                        fileObj.put("progressPercent", 100);
                        fileArr.add(fileObj);
                        String updateSql = "UPDATE " + tableName + " SET " + fieldName + "=? WHERE ID_='" + id + "'";
                        jdbcTemplate.update(updateSql, fileArr.toJSONString());
                    }
                }
            } catch (Exception e) {
                errMsg = e.getMessage();
            }
            //清理临时文件
            FileUtil.deleteDir(new File(tmpFilePath));
            if (StringUtil.isNotEmpty(errMsg)) {
                return new Response<Void>().failure(errMsg);
            }
        }
        return new Response<Void>().success();
    }

    @Override//生成申请单号
    public String getMySerialNumber(String tableName, String dateField, String statusField, int length) {
        String querySql = "SELECT COUNT(ID_) FROM " + tableName + " WHERE " +
                "TO_CHAR(" + dateField + ",'yyyy')=TO_CHAR(SYSDATE,'yyyy') AND " + statusField + "!='草稿'";
        String serialNumber = CommonTools.Obj2String(jdbcTemplate.queryForObject(querySql, Integer.class) + 1);
        while (serialNumber.length() < length) {
            serialNumber = "0" + serialNumber;
        }
        return serialNumber;
    }

    @Override//计算目标表字段值
    public Response<Void> calculateTargetFieldVal(String calculateSql, String linkField,
                                                  Set<String> targetIds, String targetTable, String targetField) {
        return this.calculateTargetFieldVal(calculateSql, linkField, targetIds, targetTable, targetField, jdbcTemplate);
    }

    @Override//计算目标表字段值
    public Response<Void> calculateTargetFieldVal(String calculateSql, String linkField,
                                                  Set<String> targetIds, String targetTable, String targetField, JdbcTemplate targetJdbc) {
        //计算
        String filterSql = MyStringUtil.getFilterSql((id) -> linkField + "='" + id + "'", targetIds);
        calculateSql = calculateSql.replace("#{filterSql}", filterSql);
        List<Map<String, Object>> numList = jdbcTemplate.queryForList(calculateSql);
        Map<String, Map<String, Object>> numMap = MyListUtil.list2Map(numList, "TARGETID");
        //批量更新
        List<String> updateSqls = new ArrayList<>();
        for (String targetId : targetIds) {
            double resNum = 0;
            Map<String, Object> numInfo = numMap.get(targetId);
            if (numInfo != null) {
                resNum = CommonTools.obj2Double(numInfo.get("TARGETNUM"));//已到货数量
            }
            updateSqls.add("UPDATE " + targetTable + " SET " + targetField + "=" + resNum + " WHERE ID_='" + targetId + "'");
        }
        if (CommonTools.isNotEmptyList(updateSqls)) {
            MyJdbcUtil.batchUpdate(targetJdbc, updateSqls);
        }
        return new Response<Void>().success();
    }

    @Override//回退目标表字段值
    public Response<Void> revertTargetFieldVal(Map<String, Integer> revertInfo, String targetTable, String targetField) {
        return this.revertTargetFieldVal(revertInfo, targetTable, targetField, jdbcTemplate);
    }

    @Override//回退目标表字段值
    public Response<Void> revertTargetFieldVal(Map<String, Integer> revertInfo, String targetTable, String targetField, JdbcTemplate targetJdbc) {
        if (revertInfo.size() > 0) {
            List<String> updateSqls = new ArrayList<>();
            for (String targetId : revertInfo.keySet()) {
                Integer resNum = revertInfo.get(targetId);
                updateSqls.add("UPDATE " + targetTable + " SET " + targetField + "=" + resNum + " WHERE ID_='" + targetId + "'");
            }
            if (CommonTools.isNotEmptyList(updateSqls)) {
                MyJdbcUtil.batchUpdate(targetJdbc, updateSqls);
            }
        }
        return new Response<Void>().success();
    }

    @Override
    public String checkInterfaceParams(JSONArray params, String requiredFields, String numberFields, String dateFields) {
        String checkMsg = "";
        if (params == null || params.size() <= 0) {
            checkMsg = "传参类型为JSONArray，元素个数须大于0";
        } else {
            int rownum = 0;
            for (int i = 0, size = params.size(); i < size; i++) {
                String rowInfo = "第" + (++rownum) + "个数据";
                JSONObject item = params.getJSONObject(i);
                String rowCheckMsg = this.checkInterfaceParam(item, requiredFields, numberFields, dateFields);
                //行校验结果
                if (StringUtil.isNotEmpty(rowCheckMsg)) {
                    rowCheckMsg = MyStringUtil.removeSuffix(rowCheckMsg, "、");
                    checkMsg += rowInfo + "【" + rowCheckMsg + "】";
                }
            }
        }
        return checkMsg;
    }

    @Override
    public String checkInterfaceParam(JSONObject param, String requiredFields, String numberFields, String dateFields) {
        String rowCheckMsg = "";
        //必填校验
        if (StringUtil.isNotEmpty(requiredFields)) {
            String[] fieldArr = requiredFields.split(",");
            for (String item : fieldArr) {
                if (!param.containsKey(item) || StringUtil.isEmpty(param.getString(item))) {
                    rowCheckMsg += item + "须非空、";
                }
            }
        }
        //数字校验
        if (StringUtil.isNotEmpty(numberFields)) {
            String[] fieldArr = numberFields.split(",");
            for (String item : fieldArr) {
                if (param.containsKey(item) && !NumberUtil.isNumber(param.getString(item))) {
                    rowCheckMsg += item + "须为数字、";
                }
            }
        }
        //日期校验
        if (StringUtil.isNotEmpty(dateFields)) {
            String[] fieldArr = dateFields.split(",");
            for (String item : fieldArr) {
                if (param.containsKey(item)) {
                    try {
                        DateUtil.parseDate(param.getString(item));
                    } catch (Exception e) {
                        rowCheckMsg += item + "须为日期格式、";
                    }
                }
            }
        }
        if (StringUtil.isNotEmpty(rowCheckMsg)) {
            rowCheckMsg = MyStringUtil.removeSuffix(rowCheckMsg, "、");
        }
        return rowCheckMsg;
    }

    @Override//得到参数管理对象
    public SysParameter getSysParameter(String alias) {
        SysParameter sysParameter = purchaseSysService.getByParamName(alias);
        return sysParameter;
    }

    @Override//得到参数管理值
    public String getSysParamVal(String alias) {
        String res = "";
        SysParameter sysParameter = this.getSysParameter(alias);
        if (sysParameter != null) {
            res = CommonTools.Obj2String(sysParameter.getValue());
        }
        return res;
    }

    @Override//批量终止流程
    public Response<Void> batchEndProcess(String procDefId, Set<String> businessKeys, String opinion) {
        try {
            if (MySetUtil.isNotEmpty(businessKeys)) {
                String filterSql = MyStringUtil.getFilterSql(item -> "T2.BUSINESS_KEY_='" + item + "'", businessKeys);
                String querySql = "SELECT T1.ID_ TASKID FROM IBMS_712S_ASSEMBLY.BPM_TASK T1 " +
                        "INNER JOIN IBMS_712S_ASSEMBLY.BPM_PRO_INST_HI T2 ON T1.PROC_INST_ID_=T2.ID_ " +
                        "WHERE T1.PROC_DEF_ID_='" + procDefId + "' " + filterSql;
                List<Map<String, Object>> dataList = MyJdbcUtil.getJdbcTemplate(MyConst.systemDataSourceAlias).queryForList(querySql);
                if (CommonTools.isNotEmptyList(dataList)) {
                    List<TaskRequestActionDto> taskDtos = new ArrayList<>();
                    dataList.forEach(item -> {
                        TaskRequestActionDto endDto = new TaskRequestActionDto();
                        endDto.setProcDefId(procDefId);
                        endDto.setTaskId(StringUtil.getObjectValue(item.get("TASKID")));
                        endDto.setApprovalOpinion(StringUtil.isNotEmpty(opinion) ? opinion : "同意终止流程");
                        taskDtos.add(endDto);
                    });
                    purchaseBpmnService.endProcessApiForBatch(taskDtos);
                }
            }
        } catch (Exception e) {
            return new Response<Void>().failure(e.getMessage());
        }
        return new Response<Void>().success();
    }
}