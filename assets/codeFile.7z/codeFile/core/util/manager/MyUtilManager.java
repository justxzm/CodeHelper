package com.ibms.purchases.util.manager;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ibms.common.web.response.Response;
import com.ibms.rest.sys.model.SysParameter;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 工具接口，仅后端调用的方法可不需Response包裹
 */
public interface MyUtilManager {

    //更新流程数据状态
    Response<Void> updateFlowStatus(String bussinessKey,
                                    String tableName, String fieldName, String status,
                                    String subTableName, String subFieldName, String subStatus);

    //更新表单数据状态
    Response<Void> updateStatus(String ids, String tableName, String fieldName, String status,
                                String refIds, String subTableName, String subFieldName, String subStatus);

    //得到流水号
    String getNextSerialNumber(String alias);

    String getNextSerialNumberOrg(String alias);

    String getNextSerialNumberOrg(String alias, String orgCode);

    //启动流程
    Response<Void> batchStartFlow(List<JSONObject> paramList);

    Response<Void> startFlow(JSONObject paramList);

    //判断用户是否为某组织负责人
    Response<Boolean> isUserChargeOrgByCode(String userCode, String orgCode, String orgIsDelete);

    //处理流程回填审批意见
    String dealWithFlowOpinion(String opinion);

    //获得流程审批意见信息
    Map<String, Map<String, Object>> getFlowOpinionInfo(String bussinessKey);

    //获得相同执行人跳过节点审批信息
    String getSkipFlowNodeInfo(String infoType, String fieldVal, Map<String, Map<String, Object>> opinionInfo, String nodeKeyPath, String curNodeKey);

    //根据用户CODE得到签章文件流
    byte[] getUserSignatureBlob(String userCode);

    //根据组织CODE得到签章文件流
    byte[] getOrgSignatureBlob(String orgCode);

    //根据用户CODE得到红章文件流
    byte[] getUserRedSignatureBlob(String userCode);


    //获得条形码文件流
    byte[] getBarCodeBlob(String value, int width, int height);

    //推立思辰打印
    Response<Void> sendToLscPrint(String funcName, String fileName, String filePath);

    //生成当前用户磁盘临时目录
    String getLocalTmpDirPath();

    //从模板导出PDF
    Response<Void> exportMyPDF(String expFileName, String templateFilePath,
                               Map<String, Object> txtFillMap, Map<String, byte[]> imgFillMap,
                               HttpServletRequest request, HttpServletResponse response);

    Response<Void> exportMyPDF(String expFileName, String templateFilePath,
                               Map<String, Object> txtFillMap, Map<String, byte[]> imgFillMap, List<byte[]> pdfAddInfo,
                               HttpServletRequest request, HttpServletResponse response);

    //从模板导出PDF(多个-zip)
    Response<Void> exportMyPDFZIP(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                  List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList,
                                  HttpServletRequest request, HttpServletResponse response);

    Response<Void> exportMyPDFZIP_add2Zip(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                          List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList, Map<String, byte[]> add2ZipMap,
                                          HttpServletRequest request, HttpServletResponse response);

    Response<Void> exportMyPDFZIP_add2Pdf(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                          List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList, List<List<byte[]>> add2PdfList,
                                          HttpServletRequest request, HttpServletResponse response);

    Response<Void> exportMyPDFZIP_add(String zipName, List<String> expFileNameList, List<String> templateFilePathList,
                                      List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList,
                                      List<List<byte[]>> add2PdfList, Map<String, byte[]> add2ZipMap,
                                      HttpServletRequest request, HttpServletResponse response);

    //从模板导出PDF(多个-合并的PDF)
    Response<Void> exportMergePDF(String pdfName, List<String> expFileNameList, List<String> templateFilePathList, List<Map<String, Object>> txtFillList, List<Map<String, byte[]>> imgFillList, HttpServletRequest request, HttpServletResponse response);

    //从模板导出PDF(多个-合并的PDF)
    Response<Void> exportMergePDF(String pdfName, byte[] pdfBytesList, HttpServletRequest request, HttpServletResponse response);

    Response<Void> exportMergePDF(String pdfName, List<byte[]> pdfBytesList, HttpServletRequest request, HttpServletResponse response);

    //得到数据字典
    Set<String> getDicValInfoSet(String dicAlias, String clientNum);

    Set<String> getDicNameInfoSet(String dicAlias, String clientNum);

    Map<String, Object> getDicValInfoMap(String dicAlias, String clientNum);

    Map<String, Object> getDicNameInfoMap(String dicAlias, String clientNum);

    Map<String, Object> getDicAllInfoMap(String dicAlias, String clientNum);

    //数据迁移hadoop文件处理
    Response<Void> dealWithHadoopFile(String tableName, String fieldName, String dataSource);

    //生成申请单号
    String getMySerialNumber(String tableName, String dateField, String statusField, int length);

    //计算目标表字段值
    Response<Void> calculateTargetFieldVal(String calculateSql, String linkField, Set<String> targetIds, String targetTable, String targetField);

    Response<Void> calculateTargetFieldVal(String calculateSql, String linkField, Set<String> targetIds, String targetTable, String targetField, JdbcTemplate targetJdbc);

    //回退目标表字段值
    Response<Void> revertTargetFieldVal(Map<String, Integer> revertInfo, String targetTable, String targetField);

    Response<Void> revertTargetFieldVal(Map<String, Integer> revertInfo, String targetTable, String targetField, JdbcTemplate targetJdbc);

    //接口传参校验
    String checkInterfaceParams(JSONArray params, String requiredFields, String numberFields, String dateFields);

    String checkInterfaceParam(JSONObject param, String requiredFields, String numberFields, String dateFields);

    //得到参数管理对象
    SysParameter getSysParameter(String alias);

    String getSysParamVal(String alias);

    //批量终止流程
    Response<Void> batchEndProcess(String procDefId, Set<String> businessKeys, String opinion);
}