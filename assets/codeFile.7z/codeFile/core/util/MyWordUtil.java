package com.ibms.purchases.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aspose.words.*;
import com.aspose.words.net.System.Data.DataRow;
import com.aspose.words.net.System.Data.DataTable;
import com.ibms.rest.file.model.SunFile;
import com.sun.xml.internal.messaging.saaj.util.ByteOutputStream;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.core.io.ClassPathResource;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.List;
import java.util.Map;

public class MyWordUtil {

    /********************************************POI***********************************************/
    /**
     * 计算WORD2007(*.docx)格式文档的页数
     */
    public static int getDocxPageNum(InputStream fileInputStream) {
        int pageCount = 0;
        XWPFDocument docx = null;
        ZipSecureFile.setMinInflateRatio(-1.0d);
        try {
            docx = new XWPFDocument(fileInputStream);
            pageCount = docx.getProperties().getExtendedProperties().getUnderlyingProperties().getPages();//总页数
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                docx.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return pageCount;
    }
    /**
     * 计算WORD2003(*.doc)格式文档的页数
     */
    public static int getDocPageNum(InputStream fileInputStream) {
        int pageCount = 0;
        WordExtractor doc = null;
        ZipSecureFile.setMinInflateRatio(-1.0d);
        try {
            doc = new WordExtractor(fileInputStream);//.doc格式Word文件提取器
            pageCount = doc.getSummaryInformation().getPageCount();//总页数
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                doc.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return pageCount;
    }

    /********************************************Aspose***********************************************/
    //注册
    public static void loadLicense() {
        License license = new License();
        InputStream is = null;
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            is = MyWordUtil.class.getResourceAsStream("/aspose.word.license.xml");
            if (is == null) {
                throw new RuntimeException("Cannot find licenses file.");
            }
            license.setLicense(is);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException ex) {
                }
                is = null;
            }
        }
    }
    //加载
    public static Document getDocument(SunFile sysFile) {
        InputStream input = new ByteArrayInputStream(sysFile.getFileBlob());
        return getDocument(input);
    }
    public static Document getDocument(String templateName) {
        ClassPathResource classPathResource = new ClassPathResource("template"+File.separator+templateName);
        InputStream input = null;
        try {
            input = classPathResource.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return getDocument(input);
    }
    public static Document getDocument(InputStream input){
        //1.加载授权文件
        loadLicense();
        //2.初始化文档对象
        Document doc = null;
        try {
            doc = new Document(input);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return doc;
    }
    //合入主表单字段
    public static void fillFormFields(Document doc, Map<String,Object> formInfo){
        Map<String,String[]> arrMap = MyMapUtil.toArrayMap(formInfo);
        String[] colNames = arrMap.get("keyArr");
        Object[] colVals = arrMap.get("valArr");
        MyWordUtil.fillFormFields(doc,colNames,colVals);
    }
    public static void fillFormFields(Document doc, String[] colNames, Object[] colVals){
        try {
            doc.getMailMerge().execute(colNames, colVals);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //合并单表列表
    public static void fillPreviewDatas(Document doc,String tableName,String[] colNames,Object dataList){
        //1.填充并返回填充好数据的表格对象
        DataTable visitTb = getFilledTable(doc,tableName,colNames,dataList);
        try {
            //2.执行填充操作
            doc.getMailMerge().executeWithRegions(visitTb);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //得到填充好数据的表格对象DataTable
    public static DataTable getFilledTable(Document doc,String tableName,String[] colNames,Object dataList){
        DataTable visitTb = new DataTable(tableName);
        //1.表格中加入表头
        for(String colName:colNames){
            visitTb.getColumns().add(colName);
        }
        if(dataList instanceof JSONArray){
            JSONArray tmpRowList = (JSONArray)dataList;
            for(int i=0,size=tmpRowList.size();i<size;i++){
                //2.填充每一行数据
                DataRow row = visitTb.newRow();
                JSONObject tmpColList = tmpRowList.getJSONObject(i);
                int colIndex = 0;
                for(String colName:colNames){
                    row.set(colIndex++, CommonTools.Obj2String(tmpColList.get(colName)));//2.1填充每一行中的每一列
                }
                visitTb.getRows().add(row);
            }
        }else if(dataList instanceof List){
            List<?> tmpRowList = (List<?>) dataList;
            for(Object rowData:tmpRowList){
                //2.填充每一行数据
                DataRow row = visitTb.newRow();
                if(rowData instanceof List){
                    List<String> tmpColList = (List<String>)rowData;
                    for(int i = 0,size=tmpColList.size(); i < size; i++){
                        row.set(i, tmpColList.get(i));//2.1填充每一行中的每一列
                    }
                }else if(rowData instanceof Map){
                    int colIndex = 0;
                    for(String colName:colNames){
                        row.set(colIndex++, CommonTools.Obj2String(((Map) rowData).get(colName)));//2.1填充每一行中的每一列
                    }
                }
                visitTb.getRows().add(row);
            }
        }
        //3.无数据则添加默认行
        if(visitTb.getRows().getCount()==0){
            DataRow row = visitTb.newRow();
            for(int i = 0,size=colNames.length; i < size; i++){
                row.set(i, "无");
            }
            visitTb.getRows().add(row);
        }
        return visitTb;
    }
    //更新SysFile对象中的文件流
    public static void updateFileBlob(SunFile sysFile, Document document) {
        ByteOutputStream outStream = new ByteOutputStream();
        String fileExt = sysFile.getExt();
        try {
            if (fileExt.equals("doc")) {
                document.save(outStream, SaveFormat.DOC);
            } else {
                document.save(outStream, SaveFormat.DOCX);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        sysFile.setFileBlob(outStream.toByteArray());
    }
    //插入图片到指定书签位置
    public static void insertImg2Bookmark(Document doc, String bookmarkName, SunFile imgFile, Integer height) throws Exception {
        insertImg2Bookmark(doc,bookmarkName,imgFile,height,WrapType.INLINE);
    }
    public static void insertImg2Bookmark(Document doc, String bookmarkName, SunFile imgFile, Integer height, int wrapType) throws Exception {
        InputStream in = new ByteArrayInputStream(imgFile.getFileBlob());
        BufferedImage bufferImg = ImageIO.read(in);
        insertImg2Bookmark(doc,bookmarkName,bufferImg,height,wrapType);
    }
    public static void insertImg2Bookmark(Document doc, String bookmarkName, byte[] imgBytes) {
        insertImg2Bookmark(doc,bookmarkName,imgBytes,null,WrapType.INLINE);
    }
    public static void insertImg2Bookmark(Document doc, String bookmarkName, byte[] imgBytes, int height) {
        insertImg2Bookmark(doc,bookmarkName,imgBytes,height,WrapType.INLINE);
    }
    public static void insertImg2Bookmark(Document doc, String bookmarkName, byte[] imgBytes, Integer height, int wrapType) {
        try {
            if(imgBytes!=null) {
                InputStream in = new ByteArrayInputStream(imgBytes);
                BufferedImage bufferImg = ImageIO.read(in);
                if (bufferImg != null) {
                    height = (height==null? bufferImg.getHeight():height);
                    insertImg2Bookmark(doc, bookmarkName, bufferImg, height, wrapType);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void insertImg2Bookmark(Document doc, String bookmarkName, BufferedImage img, Integer height, int wrapType) throws Exception {
        Integer width = (int)((double)height/img.getHeight()*img.getWidth());//按比例计算宽度
        for (Bookmark bookmarks : doc.getRange().getBookmarks()) {
            if (bookmarks != null && bookmarks.getName().equals(bookmarkName)) {
                DocumentBuilder builder = new DocumentBuilder(doc);
                //移动到书签位置
                builder.moveToBookmark(bookmarks.getName());
                //设置格式  WrapType.INLINE
                builder.insertImage(img, RelativeHorizontalPosition.DEFAULT, 1, RelativeVerticalPosition.MARGIN, 1, width, height, wrapType);
            }
        }
    }

    public static byte[] getPdfBytes(Document doc){
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        try {
            formatDocument(doc).save(byteOut, SaveFormat.PDF);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return byteOut.toByteArray();
    }

    public static void word2Pdf(String inpath, String outpath) throws Exception {
        loadLicense();
        File file = new File(outpath);
        FileOutputStream os = new FileOutputStream(file);
        try {
            Document doc = new Document(inpath);
            formatDocument(doc).save(os, SaveFormat.PDF);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public static void word2Pdf(SunFile wordFile, SunFile pdfFile){
        loadLicense();
        try{
            //转pdf
            ByteOutputStream out = new ByteOutputStream();
            Document doc = getDocument(wordFile);
            formatDocument(doc).save(out, SaveFormat.PDF);
            //更新文件信息
            String fileName = wordFile.getName();
            String storageName = wordFile.getStorageName();
            pdfFile.setFileBlob(out.toByteArray());
            pdfFile.setName(fileName.substring(0,fileName.lastIndexOf("."))+".pdf");
            pdfFile.setStorageName(storageName.substring(0,storageName.lastIndexOf("."))+".pdf");
            pdfFile.setExt("pdf");
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static Document formatDocument(Document doc){
        //优化表格排版
        NodeCollection tables = doc.getChildNodes(NodeType.TABLE, true);
        for (Table table : (Iterable<Table>) tables) {
            double tableHeight = 0;
            double tableWidth = 0;
            for (Row row : table.getRows()) {
                tableHeight += row.getRowFormat().getHeight();
                double rowWidth = 0;
                for (Cell cell : row.getCells()) {
                    rowWidth += cell.getCellFormat().getWidth();
                }
                if (rowWidth > tableWidth) {
                    tableWidth = rowWidth;
                }
            }
            Section section = (Section) table.getAncestor(NodeType.SECTION);
            double pageWidth = section.getPageSetup().getPageWidth() - (section.getPageSetup().getLeftMargin() + section.getPageSetup().getRightMargin());
            for (Row row : table.getRows()) {
                for (Cell cell : row.getCells()) {
                    double cellRatio = cell.getCellFormat().getWidth() / tableWidth;
                    cell.getCellFormat().setWidth(cellRatio * pageWidth);
                }
                if (row.getRowFormat().getHeight() > tableHeight) {
                    continue;
                }
                double height = row.getRowFormat().getHeight() / tableHeight;
                row.getRowFormat().setHeight(height * tableHeight);
            }
        }
        return doc;
    }

    public static Document getDocuments(String templateName) {
        ClassPathResource classPathResource = new ClassPathResource("template" + File.separator + templateName);
        InputStream input = null;
        try {
            input = classPathResource.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return getDocument(input);
    }
}