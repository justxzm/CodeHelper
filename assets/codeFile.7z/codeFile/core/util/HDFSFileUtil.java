package com.ibms.purchases.util;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;
import java.net.URI;

public class HDFSFileUtil {
	 
	private static FileSystem fileSystem = null;

	public static FileSystem getInstance(String hdfsUrl) throws IOException {
		if(fileSystem==null) {
			synchronized (FileSystem.class) {
				if(fileSystem==null) {
					Configuration conf = new Configuration();
					fileSystem = FileSystem.get(URI.create(hdfsUrl),conf);
				}
			}
		}
		return fileSystem;
	}

	public static void copy(String hdfsUrl, String remote,String dest) throws IOException {
		Path path = new Path(remote);
		Path path1 = new Path(dest);
		FileSystem fs = getInstance(hdfsUrl);
		fs.copyToLocalFile(false, path, path1, true);
	}
}
