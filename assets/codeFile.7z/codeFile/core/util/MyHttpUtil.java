package com.ibms.project.common.util;

import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;

import java.io.IOException;

public class MyHttpUtil {

    private final static Logger logger = LoggerFactory.getLogger(MyHttpUtil.class);

    public static JSONObject doPost(String reqUrl, JSONObject params) {
        JSONObject res = new JSONObject();
        String errMsg = "";

        HttpPost httpPost = new HttpPost(reqUrl);
        httpPost.setHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
        StringEntity entity = new StringEntity(params.toJSONString(),"UTF-8");
        httpPost.setEntity(entity);

        CloseableHttpClient httpclient = null;
        CloseableHttpResponse response = null;
        try {
            httpclient = HttpClients.createDefault();
            response = httpclient.execute(httpPost);
            StatusLine status = response.getStatusLine();
            int statusCode = status.getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                HttpEntity responseEntity = response.getEntity();
                String jsonString = EntityUtils.toString(responseEntity,"UTF-8");
                res.put("success",true);
                res.put("message",jsonString);
                return res;
            } else {
                errMsg = "接口调用失败("+statusCode+")：" + reqUrl;
            }
        } catch (Exception e) {
            errMsg = "接口调用失败：" + e.getMessage();
            logger.error("接口调用失败：", e.getMessage());
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    logger.error("response关闭失败", e);
                }
            }
            if (httpclient != null) {
                try {
                    httpclient.close();
                } catch (IOException e) {
                    logger.error("httpclient关闭失败", e);
                }
            }
        }
        res.put("success",false);
        res.put("message",errMsg);
        return res;
    }
}