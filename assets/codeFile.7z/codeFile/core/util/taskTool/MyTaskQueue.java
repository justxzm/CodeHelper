package com.ibms.purchases.util.taskTool;

import com.ibms.common.util.common.AppUtil;
import com.ibms.db.datasource.util.DataSourceUtil;
import com.ibms.purchases.materialPurchase.materialStorage.dao.MaterialStorageDao;
import com.ibms.purchases.util.MyConst;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.LinkedList;

public class MyTaskQueue {
	private JdbcTemplate jdbcTemplate = null;
	private JdbcTemplate jdbcTemplateContract = null;
	private MaterialStorageDao materialStorageDao = null;
	private final WorkThread worker;// 工作线程
	private final LinkedList<MyTaskProxy> queue;// 任务队列

	public MyTaskQueue() {
		worker = new WorkThread();
		worker.start();// 启动工作线程
		queue = new LinkedList<MyTaskProxy>();
	}

	public int getTaskNum(){
		return queue.size();
	}
	
	public void addTask(MyTaskProxy task) {// 执行任务
		long start = System.currentTimeMillis();
        synchronized (queue) {
			queue.addLast(task);
			System.out.println("加入一组任务("+(System.currentTimeMillis()-start)+"ms)，队列中任务组数量："+queue.size());
			queue.notify();
		}
	}

    // 工作线程类
	private class WorkThread extends Thread {
		public void run() {
			MyTaskProxy myTaskProxy = null;
			while (true) {
				synchronized (queue) {
					while (queue.isEmpty()) {
						try {
							queue.wait();
						} catch (InterruptedException ex) {
							ex.printStackTrace();
						}
					}
					myTaskProxy = queue.removeFirst();// 有任务时，取出任务
                    System.out.println("取出一组任务执行，队列中剩余任务组数量：" + queue.size());
				}
				if (jdbcTemplate == null) {
					jdbcTemplate = AppUtil.getBean(JdbcTemplate.class);
				}
				if (jdbcTemplateContract == null) {
					jdbcTemplateContract = DataSourceUtil.getJdbcTempByDsAlias(MyConst.contractDataSourceAlias);
				}
				if(materialStorageDao == null){
					materialStorageDao = AppUtil.getBean(MaterialStorageDao.class);
				}
				myTaskProxy.executeTask(jdbcTemplate,jdbcTemplateContract,materialStorageDao);// 执行任务
				myTaskProxy = null;
			}
		}
	}
}
