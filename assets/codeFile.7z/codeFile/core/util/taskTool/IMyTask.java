package com.ibms.purchases.util.taskTool;

import com.ibms.purchases.materialPurchase.materialStorage.dao.MaterialStorageDao;
import com.ibms.purchases.util.CommonTools;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Map;

/**
 *  @desc : 基础任务接口
 *  @author : Just.
 *  @createDate : 2020/1/4 10:33 
 */
public interface IMyTask {

	//得到任务名
    String getTaskName();

	//执行任务
	void execute(JdbcTemplate jdbcTemplate, JdbcTemplate jdbcTemplateContract, MaterialStorageDao materialStorageDao);

	//获取当前用户参数
    String curUserNameKey = "curUserName";
	String curUserCodeKey = "curUserCode";
    default String getCurUserName(Map<String, Object> params) {
        String curUserCode = "";
        if (params != null && params.containsKey(curUserNameKey)) {
            curUserCode = CommonTools.Obj2String(params.get(curUserNameKey));
        }
        return curUserCode;
    }
    default String getCurUserCode(Map<String, Object> params) {
        String curUserCode = "";
        if (params != null && params.containsKey(curUserCodeKey)) {
            curUserCode = CommonTools.Obj2String(params.get(curUserCodeKey));
        }
        return curUserCode;
    }
}
