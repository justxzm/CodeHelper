package com.ibms.purchases.util.taskTool;

import com.ibms.purchases.materialPurchase.materialStorage.dao.MaterialStorageDao;
import com.ibms.purchases.materialPurchase.materialStorage.manager.impl.MaterialStorageManagerImpl;
import org.springframework.jdbc.core.JdbcTemplate;


public class MyTaskProxy {

	private IMyTask[] myTaskArr = null;
	
	public MyTaskProxy(IMyTask[] myTaskArr){
		this.myTaskArr = myTaskArr;
	}
	
	public void executeTask(JdbcTemplate jdbcTemplate, JdbcTemplate jdbcTemplateContract, MaterialStorageDao materialStorageDao){
		String taskTitle = null;
		int curIndex = 0;
		try{
			IMyTask myTask = null;
			for(int i=0,size=myTaskArr.length;i<size;i++){
				long start = System.currentTimeMillis();
				curIndex = i;
				//1.获得任务组中一个任务
				myTask = myTaskArr[i];
				//2.获得任务名称，以便判断任务类型
				taskTitle = myTask.getTaskName();
				//3.根据当前库存做配套校验和更新库存的代码需加SyncLock锁同步
				/*if("自动配套任务".equals(taskTitle) || "库存更新任务".equals(taskTitle)){
					synchronized (MaterialStorageManagerImpl.syncLock) {
						myTask.execute(jdbcTemplate,jdbcTemplateContract);
					}
				}else{
					myTask.execute(jdbcTemplate,jdbcTemplateContract);
				}*/
				myTask.execute(jdbcTemplate,jdbcTemplateContract,materialStorageDao);
				//4.任务对象置空，以便垃圾回收
				myTask = null;
				//5.执行完成，输出日志
				System.out.print(taskTitle+"("+(System.currentTimeMillis()-start)+"ms)->");
			}
			System.out.println("任务执行完成");
		}catch(Exception e){
			System.err.print(myTaskArr[curIndex].getTaskName()+"执行失败->");
			e.printStackTrace();
		}
		myTaskArr = null;
	}
}