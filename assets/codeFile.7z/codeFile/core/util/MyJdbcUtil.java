package com.ibms.purchases.util;

import com.ibms.common.query.DefaultQueryFilter;
import com.ibms.common.query.QueryBean;
import com.ibms.common.web.page.PageJson;
import com.ibms.common.web.page.PageResult;
import com.ibms.db.datasource.util.DataSourceUtil;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MyJdbcUtil {
    //批量更新
    public static void batchUpdate(JdbcTemplate jdbcTemplate, List<String> execSqls) {
        int defaultSize = 500;
        batchUpdateGroup(jdbcTemplate, execSqls, defaultSize);
    }
    public static void batchUpdate(String datasourceAlias,List<String> execSqls){
        JdbcTemplate jt = getJdbcTemplate(datasourceAlias);
        batchUpdate(jt,execSqls);
    }
    public static void batchUpdateGroup(JdbcTemplate jdbcTemplate, List<String> execSqls, int groupSize) {
        List<List<String>> groupList = getBatchUpdateGroupList(execSqls,groupSize);
        groupList.forEach(item->jdbcTemplate.batchUpdate(item.toArray(new String[item.size()])));
    }
    //批量更新语句分组
    public static List<List<String>> getBatchUpdateGroupList(List<String> execSqls){
        int defaultSize = 500;
        return getBatchUpdateGroupList(execSqls,defaultSize);
    }
    public static List<List<String>> getBatchUpdateGroupList(List<String> execSqls, int groupSize){
        List<List<String>> groupList = new ArrayList<>();
        if (execSqls.size() > 0 && groupSize > 0) {
            for (int i = 0, size = execSqls.size(); i <= size; i++) {
                if ((i != 0 && (i % groupSize == 0)) || i == size) {
                    List<String> subSqls = null;
                    if (i != 0 && (i % groupSize == 0)) {
                        subSqls = execSqls.subList(i - groupSize, i);
                    } else {
                        int groupIndex = i / groupSize;
                        subSqls = execSqls.subList(groupIndex * groupSize, size);
                    }
                    groupList.add(subSqls);
                }
            }
        }
        return groupList;
    }

    public static DefaultQueryFilter getDefaultFilter(String whereSql, String orderBySql){
        DefaultQueryFilter queryFilter = new DefaultQueryFilter();
        queryFilter.setPage(null);
        queryFilter.getParams().put("whereSql", whereSql);
        queryFilter.getParams().put("orderBySql", orderBySql);
        return queryFilter;
    }

    public static JdbcTemplate getJdbcTemplate(String datasourceAlias){
        return DataSourceUtil.getJdbcTempByDsAlias(datasourceAlias);
    }


    public static List<String> getPageSqls(JdbcTemplate jdbcTemplate,String querySql){
        return getPageSqls(jdbcTemplate,querySql,1000);
    }
    public static List<String> getPageSqls(JdbcTemplate jdbcTemplate,String querySql,int pageSize){
        List<String> pageSqls = new ArrayList<>();
        String queryNum = "SELECT COUNT(ID_) FROM ("+querySql+")";
        int rownum = jdbcTemplate.queryForObject(queryNum, Integer.class);
        for (int i = 0, size = rownum / pageSize + 1; i < size; i++) {
            int startIndex = i * pageSize;
            int endIndex = 0;
            if ((i + 1) == size) {
                endIndex = i * pageSize + rownum % pageSize;
            } else {
                endIndex = (i + 1) * pageSize;
            }
            pageSqls.add(getPageSql(querySql,startIndex,endIndex));
        }
        return pageSqls;
    }

    public static String getPageSql(String querySql,QueryBean queryBean){
        int startIndex = (queryBean.getPage()-1)*queryBean.getLimit();
        int endIndex = queryBean.getPage()*queryBean.getLimit();
        return getPageSql(querySql,startIndex,endIndex);
    }

    public static String getPageSql(String querySql,int startIndex,int endIndex){
        String pageSql = "SELECT * FROM (SELECT ROWNUM AS MYROWNUM,RES.* FROM (" + querySql + ") RES) " +
                "WHERE MYROWNUM>" + startIndex + " AND MYROWNUM<=" + endIndex;
        return pageSql;
    }

    public static PageJson getPageJson(JdbcTemplate jdbcTemplate,String querySql,List<Map<String,Object>> resList){
        String queryCount = "SELECT COUNT(ID_) FROM ("+querySql+")";
        int totalNum = jdbcTemplate.queryForObject(queryCount, Integer.class);
        PageJson pageJson = new PageJson();
        PageResult pageResult = new PageResult();
        pageResult.setTotalCount(totalNum);
        pageJson.setPageResult(pageResult);
        pageJson.setData(resList);
        return pageJson;
    }
}