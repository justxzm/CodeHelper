package com.ibms.purchases.util;

import java.util.HashMap;
import java.util.Map;

public class MyMapUtil {

    public static Map<String,String[]> toArrayMap(Map<String,Object> params){
        Map<String,String[]> resMap = new HashMap<>();
        String[] keyArr = new String[params.size()];
        String[] valArr = new String[params.size()];
        int index = 0;
        for(String key:params.keySet()){
            keyArr[index] = key;
            valArr[index] = CommonTools.Obj2String(params.get(key));
            ++index;
        }
        resMap.put("keyArr",keyArr);
        resMap.put("valArr",valArr);
        return resMap;
    }
}