package com.ibms.purchases.util;

import com.ibms.common.poi.Excel;
import com.ibms.common.poi.editor.IFontEditor;
import com.ibms.common.poi.style.Align;
import com.ibms.common.poi.style.BorderStyle;
import com.ibms.common.poi.style.Color;
import com.ibms.common.poi.style.VAlign;
import com.ibms.common.poi.style.font.BoldWeight;
import com.ibms.common.poi.style.font.Font;
import com.ibms.common.util.date.DateUtil;
import com.ibms.common.util.string.StringUtil;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MyExcelUtil {

	//设置表头
	public static int fillHeaders(Excel excel, String[] headers, String sheetName, String firstLineStr){
        excel.setWorkingSheet(0);
        int headerIndex = 0;
	    //首行提示
	    if(StringUtil.isNotEmpty(firstLineStr)){
            excel.region(headerIndex,0,headerIndex,headers.length-1).merge();
            excel.cell(headerIndex,0).value(firstLineStr);
            excel.row(headerIndex).align(Align.LEFT).vAlign(VAlign.CENTER).height(25).font(new IFontEditor() {
                @Override
                public void updateFont(Font font) {
                    font.boldweight(BoldWeight.BOLD);// 粗体
                    font.color(Color.BLACK);// 字体颜色
                    font.fontName("微软雅黑");
                }
            }).borderFull(BorderStyle.THIN, Color.BLACK);
            ++headerIndex;
        }
        //固定行
        excel.sheet(0).freeze(headerIndex+1, 0).sheetName(sheetName);
        //表头列宽
        for (int col = 0; col < headers.length; col++) {
            excel.cell(headerIndex, col).value(headers[col]).width(4500);
        }
        //表头样式
        excel.row(headerIndex).align(Align.CENTER).vAlign(VAlign.CENTER).height(25).font(new IFontEditor() {
            @Override
            public void updateFont(Font font) {
                font.boldweight(BoldWeight.BOLD);// 粗体
                font.color(Color.BLACK);// 字体颜色
                font.fontName("微软雅黑");
            }
        }).borderFull(BorderStyle.THIN, Color.BLACK);
        return headerIndex;
    }

    //设置表体
    public static void fillBodyByObjList(Excel excel, List<Object[]> list, int headerIndex) {
	    int startIndex = headerIndex+1;
        for (int i = 0; i < list.size(); i++) {
            Object[] objs = list.get(i);
            for (int j = 0; j < objs.length; j++) {
                String cellVal = CommonTools.Obj2String(objs[j]);
                if (cellVal.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
                    //日期格式
                    excel.cell(i + startIndex, j).value(cellVal).dataFormat("yyyy-mm-dd");
                } else {
                    //非日期格式列
                    excel.cell(i + startIndex, j).value(cellVal).dataFormat("@");
                }
            }
            excel.row(i + startIndex).align(Align.CENTER).vAlign(VAlign.CENTER).height(25).font(new IFontEditor() {
                @Override
                public void updateFont(Font font) {
                    font.color(Color.BLACK);// 字体颜色
                    font.fontName("微软雅黑");
                }
            }).borderFull(BorderStyle.THIN, Color.BLACK);
        }
    }
    //设置表体
    public static void fillBodyByMapList(Excel excel, List<Map<String,Object>> dataList, int headerIndex) {
        fillBodyByMapList_Add(excel,dataList,headerIndex+1);
    }
    public static int fillBodyByMapList_Add(Excel excel, List<Map<String,Object>> dataList, int startIndex) {
	    int curIndex = startIndex;
        for (int i = 0; i < dataList.size(); i++) {
            Map<String, Object> dataMap = dataList.get(i);
            curIndex = startIndex + i;
            int j = 0;
            Iterator<Map.Entry<String, Object>> iterator = dataMap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String,Object> entry = iterator.next();
                String fieldName = CommonTools.Obj2String(entry.getKey());
                if(fieldName.equals("ID_") || fieldName.equals("MYROWNUM")){
                    continue;
                }
                String cellVal = CommonTools.Obj2String(entry.getValue());
                if (cellVal.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
                    //日期格式
                    excel.cell(curIndex, j++).value(cellVal).dataFormat("yyyy-mm-dd");
                } else {
                    //非日期格式列
                    excel.cell(curIndex, j++).value(cellVal).dataFormat("@");
                }
            }
            excel.row(curIndex).align(Align.CENTER).vAlign(VAlign.CENTER).height(25).font(new IFontEditor() {
                @Override
                public void updateFont(Font font) {
                    font.color(Color.BLACK);// 字体颜色
                    font.fontName("微软雅黑");
                }
            }).borderFull(BorderStyle.THIN, Color.BLACK);
        }
        return ++curIndex;
    }

    //生成excel下载响应
    public static void download(Excel excel, HttpServletResponse response, String title){
        try {
            title = URLEncoder.encode((title + DateUtil.format(DateUtil.getCurrentDate(),"_yyyyMMddHHmmss")+"(非密).xls"), "UTF-8");
            response.setContentType("application/vnd.ms-excel.numberformat:#,##0.00");
            response.setHeader("Content-disposition", "attachment; filename=" + title);
            ServletOutputStream ouputStream = response.getOutputStream();
            excel.saveExcel(ouputStream);
            ouputStream.flush();
            ouputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
