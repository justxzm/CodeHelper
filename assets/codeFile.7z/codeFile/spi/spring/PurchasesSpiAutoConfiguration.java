package com.ibms.purchases.spi.spring;

import com.ibms.purchases.service.IPurchaseBpmnService;
import com.ibms.purchases.service.IPurchaseFileService;
import com.ibms.purchases.service.IPurchaseSysService;
import com.ibms.purchases.service.impl.PurchaseBpmnService;
import com.ibms.purchases.service.impl.PurchaseFileService;
import com.ibms.purchases.service.impl.PurchaseSysService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 合同管理系统与其它模块集成服务初始化
 */
@Configuration
public class PurchasesSpiAutoConfiguration {

    @Bean
    public IPurchaseSysService purchaseSysService() {
        return new PurchaseSysService();
    }

    @Bean
    public IPurchaseFileService purchaseFileService() {
        return new PurchaseFileService();
    }

    @Bean
    public IPurchaseBpmnService purchaseBpmnService(){
        return new PurchaseBpmnService();
    }
}
