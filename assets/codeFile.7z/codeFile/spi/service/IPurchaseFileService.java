package com.ibms.purchases.service;

import com.alibaba.fastjson.JSONArray;
import com.ibms.rest.file.model.FileStorageConfig;
import com.ibms.rest.file.model.SunFile;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 系统模块集成接口
 */
public interface IPurchaseFileService {

    //复制平台文件
    SunFile copyFileByFile(SunFile sysFile);
    SunFile copyFileByFileId(String fileId);

    //获得文件信息
    SunFile getFileById(String fildId);
    SunFile getFileByJson(JSONArray fileFieldVal);
    List<SunFile> getFileByIds(String[] fileIds);

    //更新文件对象
    SunFile updateFileInfo(SunFile sunFile);
    SunFile updateFileObj(SunFile sunFile);
    String downloadByFileId(SunFile sunFile);

    //获得文件存储信息
    FileStorageConfig getStorageConfByName(String name);

    //上传文件到平台
    SunFile customUpload(MultipartFile multipartFile,String jsonStr);
}
