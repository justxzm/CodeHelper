package com.ibms.purchases.service;

import com.ibms.rest.bpmn.model.BpmInstance;
import com.ibms.rest.bpmn.model.StartRequestActionDto;
import com.ibms.rest.bpmn.model.TaskRequestActionDto;

import java.util.List;

/**
 * 系统模块集成接口
 */
public interface IPurchaseBpmnService {

    /**
     * 批量启动流程
     */
    List<BpmInstance> startApiForBatch(List<StartRequestActionDto> startList);

    /**
     * 批量终止流程
     */
    void endProcessApiForBatch(List<TaskRequestActionDto> taskDtos);
}