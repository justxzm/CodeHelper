package com.ibms.purchases.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.ibms.common.web.response.Response;
import com.ibms.purchases.service.IPurchaseFileService;
import com.ibms.rest.file.feign.IFileManageService;
import com.ibms.rest.file.feign.IFileStorageService;
import com.ibms.rest.file.model.FileStorageConfig;
import com.ibms.rest.file.model.SunFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 系统模块集成实现类
 */
public class PurchaseFileService implements IPurchaseFileService {

    @Autowired(required = false)
    IFileManageService fileManageService;
    @Autowired(required = false)
    IFileStorageService fileStorageService;

    @Override
    public SunFile copyFileByFile(SunFile sysFile) {
        if (fileManageService != null) {
            Response<SunFile> response = fileManageService.copyFileByFile(sysFile);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SunFile copyFileByFileId(String fileId) {
        if (fileManageService != null) {
            Response<SunFile> response = fileManageService.copyFileByFileId(fileId);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SunFile getFileById(String fileId) {
        return this.getFileByIds(new String[]{fileId}).get(0);
    }

    @Override
    public SunFile getFileByJson(JSONArray fileFieldVal) {
        String fileId = fileFieldVal.getJSONObject(0).getString("id");
        return this.getFileByIds(new String[]{fileId}).get(0);
    }

    @Override
    public List<SunFile> getFileByIds(String[] fileIds) {
        if (fileManageService != null) {
            Response<List<SunFile>> response = fileManageService.getFile(fileIds);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SunFile updateFileInfo(SunFile sunFile) {
        if (fileManageService != null) {
            Response<SunFile> response = fileManageService.update(sunFile);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SunFile updateFileObj(SunFile sunFile) {
        if (fileManageService != null) {
            Response<SunFile> response = fileManageService.updateFile(sunFile);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public String downloadByFileId(SunFile sunFile) {
        if (fileManageService != null) {
            Response<String> response = fileManageService.downloadByFileId(sunFile.getId());
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public FileStorageConfig getStorageConfByName(String name) {
        if (fileStorageService != null) {
            Response<FileStorageConfig> response = fileStorageService.getByName(name);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SunFile customUpload(MultipartFile multipartFile, String jsonStr) {
        if (fileManageService != null) {
            Response<SunFile> response = fileManageService.customUpload(multipartFile,jsonStr);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    private String dealWithException(Response<?> response){
        return response.getMeta().getMessage();
    }
    private String getServiceNotFoundMsg(){
        return "系统暂未集成系统管理服务";
    }
}