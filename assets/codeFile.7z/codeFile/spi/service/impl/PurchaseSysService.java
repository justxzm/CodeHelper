package com.ibms.purchases.service.impl;

import com.ibms.common.web.response.Response;
import com.ibms.purchases.service.IPurchaseSysService;
import com.ibms.rest.form.feign.IFormIdentityService;
import com.ibms.rest.mdm.feign.IPositionService;
import com.ibms.rest.mdm.feign.ISysOrgService;
import com.ibms.rest.mdm.feign.ISysUserService;
import com.ibms.rest.mdm.feign.IUserPositionService;
import com.ibms.rest.mdm.model.Position;
import com.ibms.rest.mdm.model.SysOrg;
import com.ibms.rest.mdm.model.SysUser;
import com.ibms.rest.mdm.model.UserPosition;
import com.ibms.rest.sys.feign.ISysParameterService;
import com.ibms.rest.sys.model.SysParameter;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 系统模块集成实现类
 */
public class PurchaseSysService implements IPurchaseSysService {

    @Autowired(required = false)
    ISysParameterService sysParameterService;

    @Autowired(required = false)
    private ISysUserService sysUserService;

    @Autowired(required = false)
    private ISysOrgService sysOrgService;

    @Autowired(required = false)
    private IPositionService positionService;

    @Autowired(required = false)
    private IUserPositionService userPositionService;

    @Autowired(required = false)
    private IFormIdentityService formIdentityService;


    @Override
    public String getParamValue(String paramName) {
        if (sysParameterService != null) {
            Response<String> response = sysParameterService.getValueByParamName(paramName);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SysParameter getByParamName(String paramName) {
        if (sysParameterService != null) {
            Response<SysParameter> response = sysParameterService.getByParamName(paramName);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SysUser getByUserAccount(String userCode, String status) {
        if (sysUserService != null) {
            Response<SysUser> response = sysUserService.getByUserAccount(userCode,status);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException();
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SysUser getByUserId(String userId) {
        if (sysUserService != null) {
            Response<SysUser> response = sysUserService.getByUserId(userId);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException();
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SysUser getUserBySignId(String signId) {
        if (sysUserService != null) {
            Response<SysUser> response = sysUserService.getUserBySignId(signId);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException();
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<SysUser> getUserByName(String userName) {
        if (sysUserService != null) {
            Response<List<SysUser>> response = sysUserService.getUserByUserName(userName);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException();
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SysOrg getByOrgId(String orgId) {
        if (sysOrgService != null) {
            Response<SysOrg> response = sysOrgService.getByOrgId(orgId);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SysOrg getByOrgCode(String orgCode) {
        if (sysOrgService != null) {
            Response<SysOrg> response = sysOrgService.getByOrgCode(orgCode);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public SysOrg getUserMainOrgByUserCode(String userCode) {
        if (sysOrgService != null) {
            Response<SysOrg> response = sysOrgService.getUserMainOrgByUserCode(userCode);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<SysOrg> getOrgByName(String orgName, String isDeleted) {
        if (sysOrgService != null) {
            Response<List<SysOrg>> response = sysOrgService.getByOrgName(orgName,isDeleted);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public Position getByOrgCodeAndJobCode(String orgCode, String jobCode, String isDelete){
        if (positionService != null) {
            Response<Position> response = positionService.getByOrgCodeAndJobCode(orgCode,jobCode,isDelete);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<UserPosition> getUserPositionByUserCode(String userCode, String isDelete) {
        if (userPositionService != null) {
            Response<List<UserPosition>> response = userPositionService.getUserPositionByUserCode(userCode, isDelete);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<SysUser> getUsersByRoleCode(String roleCode, String clientNum, String status) {
        if (sysUserService != null) {
            Response<List<SysUser>> response = sysUserService.getUsersByRoleCode(roleCode,clientNum,status);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<SysUser> getUsersByOrgCode(String orgCode, String status) {
        if (sysUserService != null) {
            Response<List<SysUser>> response = sysUserService.getUsersByOrgCode(orgCode,status);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<SysUser> getUsersByJobCode(String jobCode, String status) {
        if (sysUserService != null) {
            Response<List<SysUser>> response = sysUserService.getUsersByJobCode(jobCode,status);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<SysUser> getUsersByPosCode(String posCode, String status) {
        if (sysUserService != null) {
            Response<List<SysUser>> response = sysUserService.getUsersByPosCode(posCode,status);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public List<SysUser> getUsersByOrgJobCode(String orgCode, String jobCode) {
        return getUsersByOrgJobCode(orgCode,jobCode,"active","0");
    }

    @Override
    public List<SysUser> getUsersByOrgJobCode(String orgCode, String jobCode, String orgStatus, String jobIsDelete) {
        Position position = this.getByOrgCodeAndJobCode(orgCode,jobCode,jobIsDelete);//公文管理员
        List<SysUser> userList = this.getUsersByPosCode(position.getCode(),orgStatus);
        return userList;
    }

    @Override
    public List<UserPosition> getOrgChargeByCode(String orgCode, String isDelete){
        if (userPositionService != null) {
            Response<List<UserPosition>> response = userPositionService.getOrgChargeByCode(orgCode,isDelete);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public String getNextSerialNumber(String alias, String clientNum) {
        if (formIdentityService != null) {
            Response<String> response = formIdentityService.getNextIdByAlias(alias, clientNum);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }
            throw new RuntimeException(dealWithException(response));
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    private String dealWithException(Response<?> response){
        return response.getMeta().getMessage();
    }
    private String getServiceNotFoundMsg(){
        return "系统暂未集成系统管理服务";
    }
}