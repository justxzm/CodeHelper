package com.ibms.purchases.service.impl;

import com.ibms.common.web.response.Response;
import com.ibms.purchases.service.IPurchaseBpmnService;
import com.ibms.rest.bpmn.feign.IBpmInstanceActionRestService;
import com.ibms.rest.bpmn.feign.IBpmTaskActionRestService;
import com.ibms.rest.bpmn.model.BpmInstance;
import com.ibms.rest.bpmn.model.StartRequestActionDto;
import com.ibms.rest.bpmn.model.TaskRequestActionDto;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 系统模块集成实现类
 */
public class PurchaseBpmnService implements IPurchaseBpmnService {

    @Autowired(required = false)
    private IBpmInstanceActionRestService bpmInstanceActionRestService;
    @Autowired(required = false)
    private IBpmTaskActionRestService bpmTaskActionRestService;

    @Override
    public List<BpmInstance> startApiForBatch(List<StartRequestActionDto> startList) {
        if (bpmInstanceActionRestService != null) {
            Response<List<BpmInstance>> response = bpmInstanceActionRestService.startApiForBatch(startList);
            if (response.getMeta().isSuccess()) {
                return response.getData();
            }else{
                return reTryStartFlow(startList,1);
            }
        }
        throw new RuntimeException(getServiceNotFoundMsg());
    }

    @Override
    public void endProcessApiForBatch(List<TaskRequestActionDto> taskDtos) {
        if(bpmTaskActionRestService != null){
            Response<Void> response = bpmTaskActionRestService.endProcessApiForBatch(taskDtos);
            if(!response.getMeta().isSuccess()){
                throw new RuntimeException(dealWithException(response));
            }
        }else{
            throw new RuntimeException(getServiceNotFoundMsg());
        }
    }

    //发起重试，最多尝试三次
    private List<BpmInstance> reTryStartFlow(List<StartRequestActionDto> startList,int tryNum){
        Response<List<BpmInstance>> response = bpmInstanceActionRestService.startApiForBatch(startList);
        if (response.getMeta().isSuccess()) {
            return response.getData();
        }else{
            if(tryNum>=3){
                throw new RuntimeException(dealWithException(response));
            }else{
                return reTryStartFlow(startList,++tryNum);
            }
        }
    }

    private String dealWithException(Response<?> response){
        return response.getMeta().getMessage();
    }
    private String getServiceNotFoundMsg(){
        return "系统暂未集成系统管理服务";
    }
}
