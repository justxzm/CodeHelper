package com.ibms.purchases.service;

import com.ibms.rest.mdm.model.Position;
import com.ibms.rest.mdm.model.SysOrg;
import com.ibms.rest.mdm.model.SysUser;
import com.ibms.rest.mdm.model.UserPosition;
import com.ibms.rest.sys.model.SysParameter;

import java.util.List;

/**
 * 系统模块集成接口
 */
public interface IPurchaseSysService {

    /**
     * 获取系统参数值
     */
    String getParamValue(String paramName);
    SysParameter getByParamName(String paramName);

    /**
     * 获得用户信息
     */
    SysUser getByUserAccount(String userCode, String status);
    SysUser getByUserId(String userId);
    SysUser getUserBySignId(String signId);
    List<SysUser> getUserByName(String userName);

    /**
     * 获得组织信息
     */
    SysOrg getByOrgId(String orgId);
    SysOrg getByOrgCode(String orgCode);
    SysOrg getUserMainOrgByUserCode(String userCode);
    List<SysOrg> getOrgByName(String orgName, String isDeleted);

    /**
     * 获得岗位信息
     */
    Position getByOrgCodeAndJobCode(String orgCode, String jobCode, String isDelete);//组织下岗位
    List<UserPosition> getUserPositionByUserCode(String userCode, String isDelete);//用户所有岗位

    /**
     * 获取角色下用户
     */
    List<SysUser> getUsersByRoleCode(String roleCode, String clientNum, String status);
    /**
     * 获取组织下用户
     */
    List<SysUser> getUsersByOrgCode(String orgCode, String status);

    /**
     * 获得职务下用户
     */
    List<SysUser> getUsersByJobCode(String jobCode, String status);

    /**
     * 获得岗位下用户
     */
    List<SysUser> getUsersByPosCode(String posCode, String status);
    List<SysUser> getUsersByOrgJobCode(String orgCode, String jobCode);
    List<SysUser> getUsersByOrgJobCode(String orgCode, String jobCode, String orgStatus, String jobIsDelete);

    /**
     * 获取组织领导
     */
    List<UserPosition> getOrgChargeByCode(String orgCode, String isDelete);

    /**
     * 获取流水号
     */
    String getNextSerialNumber(String alias, String clientNum);

}